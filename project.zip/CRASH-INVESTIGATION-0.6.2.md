# Chrome Deck 0.6.2 — playback crash investigation

## Reported symptom
The user reports that playback from the local music library begins, then approximately 30 seconds later Android displays “Chrome Deck keeps crashing” and playback stops. Internet radio has not yet been tested.

## Code-review finding and mitigation
The 0.6.1 `AudioEffectsController.attach()` created Equalizer, BassBoost, and PresetReverb native Android audio-effect instances for every player audio session, even when the DSP setting was disabled. This is unnecessary native audio integration on the default playback path and is a plausible device-specific stability risk.

In 0.6.2:
- Native DSP effects are not instantiated unless the user explicitly enables DSP.
- Disabling DSP releases the native effect instances.
- Enabling DSP attaches effects to the current ExoPlayer audio session.
- Missing/incompatible OEM effect implementations are handled without blocking normal playback.
- App version is 0.6.2 (versionCode 27).
- GitHub Actions artifact label now matches 0.6.2.

## Important diagnostic limitation
This is a code-review mitigation, NOT a confirmed root-cause fix. No Android runtime crash log was supplied, no APK build was executed in this environment, and no physical-device test was possible here. The crash may have another cause.

## Next validation
1. Build the debug APK with the included GitHub Actions workflow.
2. Install over the existing app (keep the same application ID and signing key).
3. Play several local tracks for at least 5–10 minutes with DSP disabled.
4. Repeat with internet radio separately.
5. If it still crashes, capture the Android crash report / Logcat `FATAL EXCEPTION` and `Caused by` section.
