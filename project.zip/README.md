# Chrome Deck 0.0.0.8

This is the corrected Chrome Deck Android project.

## Fix in 0.0.0.8
- Corrected the `AnalyticsListener` import to the Media3 ExoPlayer analytics package: `androidx.media3.exoplayer.analytics.AnalyticsListener`.
- Bumped the app version to `0.0.0.8` (versionCode 8).

## Build
Open the project in Android Studio or use your existing GitHub Actions workflow to run `:app:assembleDebug`.

The project uses Android Gradle Plugin and Kotlin plugins declared in the root Gradle build files. A full Android Gradle build has not been run in this environment, so GitHub Actions must confirm compilation.
