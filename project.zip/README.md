# Chrome Deck 0.2.0-dev

Native Android music player and automotive-inspired infotainment interface built with Kotlin, Jetpack Compose, and Media3.

## Source snapshot

This development package was based on the newly supplied `project(4).zip`. Existing source files and features were retained and modified in place. The project currently uses:

- Kotlin + Jetpack Compose
- Android Gradle Plugin 8.7.3 (as declared by the project build setup)
- compileSdk 35 / minSdk 26 / targetSdk 35
- Java 17
- Media3 ExoPlayer and MediaLibraryService

## Changes in this development snapshot

- Changed the portrait Now Playing surface from the bright Frutiger Aero-style backdrop and pale glass card to a dark charcoal automotive-style panel.
- Preserved the reflected album artwork beneath the main cover.
- Made the current artist name an interactive entry to Artist Details.
- Added an Artist Details screen that groups the artist's tracks from the local music library and lets the user play them.
- Added a separate Phone Book screen with contact search and a Call action that opens Android's dialer for confirmation.
- Added the `READ_CONTACTS` permission; it is requested only when the user opens the Phone Book and chooses to grant access.
- Updated the development version label to `0.2.0-dev` (versionCode 20).

## Important feature boundaries

- Artist biographies, artist portraits, and verified popular tracks outside the local library are not connected to a licensed metadata provider yet. Artist Details currently uses locally available music and album artwork only.
- Phone Book opens the system dialer using `ACTION_DIAL`; it does not place calls directly.
- The Music Tag Editor (including embedded album-art replacement), expanded settings, the full icon redesign, hardware FM tuner, SiriusXM, traffic speech reports, and the remaining 0.2.0 feature plan are not implemented in this snapshot.
- Dynamic Spot compatibility relies on the existing Android Media3 media-session/service integration. Detection by the separate dynamicSpot app has not been verified on a device.
- The Galaxy A20's hardware FM tuner still requires device/carrier-specific validation and a supported tuner interface; it is not exposed as a working tuner in this build.

## Build and test status

This package has been source-edited and archive-checked only. A Gradle build, APK build, emulator test, and physical-device test have **not** been performed in this environment. The project has no Gradle wrapper, and no system Gradle or Android SDK was available when this package was prepared. Use the repository's GitHub Actions build to compile it, then install and test on the Galaxy A20 before treating it as a release.
