# Chrome Deck 0.0.1.0

This update adds:
- Android Auto / media-library browsing for saved radio stations, playlists, and local songs.
- Shared playback controls through the existing ExoPlayer session.
- FM metadata artwork lookup using both artist and track title.
- Station-logo fallback using Radio-Browser favicon data and a domain favicon fallback.
- Generic Chrome Deck radio artwork when no image can be found.
- A 24 MB artwork cache that reuses downloaded artwork offline.
- Existing compact and expanded home-screen playback widgets are retained.

Radio streams and new artwork lookups still require an internet connection. Cached artwork can be shown offline. Android Auto availability and behavior must be confirmed on a compatible vehicle/head unit after installing the build.
