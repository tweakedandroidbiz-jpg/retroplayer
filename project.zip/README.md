# Chrome Deck 0.0.0.6

This is the Android Studio source project for Chrome Deck. It keeps the original Compose interface and adds the following Wave features:

- Device audio-session DSP: equalizer, bass boost, preset reverb, master enable, saved band levels, and Normal / Slowed+Reverb / Nightcore / Bass Boost presets.
- Playback speed from 0.25x to 4.0x with pitch lock, including live radio streams.
- Synced LRC lyric parsing and highlighting, tap-to-seek, importing `.lrc` files, and synced lyrics preferred when the lyrics service provides them.
- Persistent playlists, add/remove/rename/delete, play/shuffle, queue-next, and an Up Next screen.
- Recent radio searches (up to 10), removable/clearable search history, and popular station recommendations.
- Classic voice-command prompt (“Please say a command”) using Android TTS and SpeechRecognizer, with playback, effects, speed, library, playlist, and radio commands.
- Landscape Drive Mode keeps the display awake while active and shows the current synced lyric line.
- ExoPlayer's audio-focus handling remains enabled; car-audio reconnection can resume only when playback had been interrupted by a car output disconnect and the user has not manually paused.

## Build

The project uses Android Gradle Plugin, Kotlin Compose, and Media3 dependencies declared in the Gradle files. This ZIP does not include a Gradle wrapper or a `.github/workflows` file; retain the workflow already configured in your repository when replacing the source files.

The source was edited in this environment, but a full Android Gradle build could not be run here because a Gradle installation / Android SDK is not available. Let GitHub Actions compile it and check the build log before installing the APK.
