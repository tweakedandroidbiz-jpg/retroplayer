# Chrome Deck 0.2.1 — combined update package

Chrome Deck is a native Android music player and automotive-inspired infotainment app built with Kotlin, Jetpack Compose, and Media3.

## Project configuration

- Application ID: `com.example.retroplayer` (kept stable so existing app data can be retained when updating)
- App version: `0.2.1` (versionCode 22)
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Gradle: 8.9
- compileSdk / targetSdk: 35
- minSdk: 26 (Android 8.0)
- Java: 17
- Media3: 1.4.1

## Included features

### Music playback and library

- Local music library scanning and Media3 playback
- Queue controls, shuffle, playback speed and pitch lock
- Favorites, playlists, recently played, most played, and play history
- Lyrics lookup/manual lyrics storage
- System equalizer integration and audio effects presets
- Sleep timer with selectable durations
- Recently Played Albums, sorted by the most recently played track in each album
- Music Statistics for library size, tracked plays, favorite count, top track, top artist, and recent listening history
- Smart Mixes generated locally from favorites and listening history: Daily Drive, Heavy Rotation, Favorites Mix, Rediscover, Because You Like, and Surprise Me
- Existing Now Playing screen retains reflected album artwork and artist-name navigation
- Typography selector with Classic Automotive, System Sans, and Condensed Display options; Classic Automotive is a license-safe Android system-font approximation, not Kia's proprietary UVO font
- Portable `.cdprofile` export/import for supported appearance and preference settings, with schema validation and safe defaults
- In-app AI acknowledgements crediting Claude for the original code foundation, Gemini for ideas, and ChatGPT for additional coding assistance and ideas

### Artist details

- Artist page lists local tracks grouped by album and plays them
- Favorite-artist toggle stored locally
- Biography and portrait lookup through Wikipedia's public API, with source link
- Popular/catalog tracks from Apple's iTunes Search API, labeled as library or non-library tracks; external results are information/discovery links and are not presented as local playable files

### Radio

- Existing FM/internet radio player and station presets
- Chrome Deck Airwaves, an original free-internet-radio guide organized by decade and genre
- Decade categories (including 1940s through 2010s) are separate from the current-hits-style Today's Top 40 category
- Airwaves uses Radio Browser's community directory. The directory does not certify each station's music licensing, and stream availability is controlled by broadcasters. No SiriusXM streams, subscription, logos, channel names, or app handoffs are used.

### Travel and utilities

- Separate permanent Travel navigation entry
- Weather/forecast from Open-Meteo and active U.S. weather alerts from the National Weather Service
- Radar, traffic, and fuel sections provide source-aware handoffs where a dependable native feed is not connected
- Sports and News are not represented as live native feeds in this package

### Phone and Android integration

- Phone Book contact search with `READ_CONTACTS` permission requested when opened
- Contact selection opens the Android dialer with the number filled in; Chrome Deck does not place calls
- Media playback service, Android media controls, notification/widget support, and car-audio output detection

## Important limitations — not complete

This is the combined source update assembled from the supplied project and the work completed in this session. It is **not** an implementation of every idea previously discussed. The following requested features are still incomplete or absent:

- A true embedded audio-file tag editor that writes ID3/MP4/FLAC metadata and album art to the files. The current app does not claim to do this.
- Full artist fact sheets such as verified years active, detailed genre histories, and editable custom artist profiles/photos. Biography and portrait lookup is best-effort Wikipedia data and can be unavailable or mismatched; confirm the artist before relying on it.
- A redesigned, multi-band custom equalizer UI and full audio visualizer
- Crossfade and advanced gapless transition controls
- In-app album-art crop/rotate/reposition and apply-to-album editing
- Full recommendations based on a remote music catalog; current Smart Mixes are local-library heuristics
- Native embedded radar tiles, verified live traffic incident feed, live fuel-price feed, native sports scores, and native news feed
- Category-specific Travel text-to-speech broadcasts and broadcast-all controls
- Hardware FM tuner validation for the exact Galaxy A20 model/carrier variant; Android does not expose a universal FM tuner API for third-party apps
- Editable custom station-logo import/crop workflow and full station artwork management are not included in this update
- Advanced physical FM tuning, scanning, and RDS metadata are not implemented; the existing radio remains internet-stream based
- Dynamic Spot compatibility has not been tested with the separate dynamicSpot app; Android media-session integration is provided but cannot guarantee third-party app recognition

The Galaxy A20's hardware FM capability varies by exact model/region/carrier and has not been validated in this source environment. Android does not expose a universal FM tuner API for third-party apps.

## Data sources and behavior

- Open-Meteo: weather forecast and geocoding. Attribution is shown in the app.
- U.S. National Weather Service: active U.S. weather alerts.
- Wikipedia public API: best-effort artist biography/portrait lookup. Wikipedia content is user-edited and may not be available for every artist.
- Apple iTunes Search API: catalog track metadata and external discovery links.
- Radio Browser: community-maintained internet radio station directory. Stations may be offline, change stream URLs, or have licensing conditions that Chrome Deck has not independently audited.
- FL511: official Florida traffic information is opened externally because a dependable supported public native API was not established.
- RainViewer: radar map handoff; it is not embedded as a native in-app radar layer.

## Build instructions

A GitHub Actions workflow is included at `.github/workflows/android.yml`. Push this project to a GitHub repository and run the **Android build** workflow (or push to `main`/`master`). It installs JDK 17 and Gradle 8.9, runs `gradle assembleDebug`, and uploads the debug APK as an artifact.

No APK build or physical-device test was performed in the current environment because the Android SDK and system Gradle were unavailable. ZIP integrity and XML well-formedness can be checked here, but those checks do not replace a real Android build and device test.
