# Chrome Deck v0.0.0.7

This is the corrected project package based on the supplied Chrome Deck v0.0.0.5 project.

## Fix in v0.0.0.7

The audio-session callback now uses Media3 `AnalyticsListener.onAudioSessionIdChanged(EventTime, audioSessionId)` rather than overriding a method on `androidx.media3.common.AudioListener`. This addresses the Kotlin compiler error reported at `MainActivity.kt:548`.

## Build

The repository's existing GitHub Actions workflow should remain in place. Upload/replace the project files, commit, and run the existing workflow. This package has not been compiled in a local Android SDK environment, so the GitHub Actions result is still the build verification.
