# Chrome Deck 0.0.1.0 — development update

This source snapshot retains the existing native Kotlin, Jetpack Compose, Media3 playback, Android Auto service, widgets, local music, radio, audio effects, lyrics, and voice assistant implementations.

## Travel & Info Center foundation added

- Added a dedicated Travel & Info Center entry from the Home screen and Drive Mode rail.
- Added a native dark automotive-style section with Weather, Radar, Traffic, Fuel, Sports, and News tabs.
- Weather uses Open-Meteo geocoding/current conditions/five-day forecast data.
- Active U.S. weather alerts are requested from the National Weather Service by the resolved map point.
- Weather snapshots are cached in memory for up to 20 minutes; a manual refresh is available.
- Radar opens RainViewer's website for interactive map viewing. This is an external handoff, not an embedded radar map yet.
- Traffic now prioritizes Florida's official FL511 / FDOT service. The native Traffic tab opens the official statewide FL511 map and its documented map-layer setup page. FL511 documents a website embed tool, but a supported public native-app data API has not yet been confirmed; Chrome Deck does not scrape the site or claim to display live traffic data natively.
- Fuel opens nearby station searches. Chrome Deck does not claim to provide live individual-station fuel prices yet.
- Sports and News tabs are clearly marked as awaiting selection of documented/licensed providers; no fabricated scores or headlines are shown.
- Open-Meteo and NWS attribution is displayed in the weather section.

## Florida-first source policy

- Prefer official Florida state sources for Florida-specific travel information.
- FL511 is the preferred traffic source. Its official service documents real-time incidents, congestion, construction, closures, travel times, camera snapshots, and map layers.
- The current integration is an official external handoff, not a native live-data feed. Direct third-party feed access or a public native API must be confirmed with FDOT before implementation.

## Important verification status

This update is source-edited and archive-checked only. A Gradle build and APK/device test have not been performed in this environment because the project has no Gradle wrapper and no system Gradle/Android SDK is available here. Run the GitHub Actions build before installing. The version remains 0.0.1.0; this is an intermediate development snapshot, not the completed 0.1.0 release.

## Existing Android Auto note

Android Auto availability and behavior must be confirmed on a compatible vehicle/head unit after installing the build.
