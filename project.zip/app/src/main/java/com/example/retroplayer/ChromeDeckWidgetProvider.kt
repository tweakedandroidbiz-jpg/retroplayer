package com.example.retroplayer

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.media3.common.Player

/** Home-screen playback widget. Uses the same app-wide ExoPlayer as the main UI. */
class ChromeDeckWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.retroplayer.widget.TOGGLE"
        const val ACTION_PREVIOUS = "com.example.retroplayer.widget.PREVIOUS"
        const val ACTION_NEXT = "com.example.retroplayer.widget.NEXT"
        const val ACTION_OPEN = "com.example.retroplayer.widget.OPEN"

        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, ChromeDeckWidgetProvider::class.java)
            manager.getAppWidgetIds(component).forEach { updateOne(context, manager, it) }
            val mini = ComponentName(context, ChromeDeckMiniWidgetProvider::class.java)
            manager.getAppWidgetIds(mini).forEach { updateForLayout(context, manager, it, R.layout.chrome_deck_widget_mini) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            updateForLayout(context, manager, id, R.layout.chrome_deck_widget)
        }

        internal fun updateForLayout(context: Context, manager: AppWidgetManager, id: Int, layoutId: Int) {
            val views = RemoteViews(context.packageName, layoutId)
            val app = context.applicationContext as? RetroApp
            val player = app?.player
            val station = player?.station
            val song = player?.current
            val title = when {
                station != null -> player.icyTitle?.substringBefore(" - ")?.takeIf { it.isNotBlank() } ?: station.name
                song != null -> song.title?.takeIf { it.isNotBlank() } ?: "Unknown track"
                else -> "Nothing playing"
            }
            val subtitle = when {
                station != null -> if (!player.icyTitle.isNullOrBlank()) station.name else "Internet radio"
                song != null -> song.artist?.takeIf { it.isNotBlank() } ?: song.album ?: "Chrome Deck"
                else -> "Tap to open Chrome Deck"
            }
            views.setTextViewText(R.id.widget_title, title)
            views.setTextViewText(R.id.widget_subtitle, subtitle)
            views.setTextViewText(R.id.widget_play, if (player?.exo?.isPlaying == true) "Ⅱ" else "▶")
            views.setTextViewText(R.id.widget_brand, "CHROME DECK")

            views.setOnClickPendingIntent(R.id.widget_play, action(context, ACTION_TOGGLE, id * 10 + 1))
            views.setOnClickPendingIntent(R.id.widget_previous, action(context, ACTION_PREVIOUS, id * 10 + 2))
            views.setOnClickPendingIntent(R.id.widget_next, action(context, ACTION_NEXT, id * 10 + 3))
            views.setOnClickPendingIntent(R.id.widget_root, action(context, ACTION_OPEN, id * 10 + 4))
            manager.updateAppWidget(id, views)
        }

        private fun action(context: Context, action: String, requestCode: Int): PendingIntent {
            val intent = Intent(context, ChromeDeckWidgetProvider::class.java).setAction(action)
            return PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val app = context.applicationContext as? RetroApp ?: return
        val player = app.player
        when (intent.action) {
            ACTION_TOGGLE -> {
                if (player.exo.isPlaying) player.pauseByUser() else player.playByUser()
            }
            ACTION_PREVIOUS -> player.previous()
            ACTION_NEXT -> player.next()
            ACTION_OPEN -> {
                val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
                launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                if (launch != null) context.startActivity(launch)
            }
        }
        refresh(context)
    }
}
