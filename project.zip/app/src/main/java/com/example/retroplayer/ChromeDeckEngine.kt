package com.example.retroplayer

import android.content.Context
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.UtteranceProgressListener
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

/** Timestamped lyric line parsed from an LRC file. */
data class LyricLine(val timeMs: Long, val text: String)

object LrcParser {
    private val stamp = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?]")

    fun parse(source: String): List<LyricLine> {
        val out = mutableListOf<LyricLine>()
        source.lineSequence().forEach { line ->
            val matches = stamp.findAll(line).toList()
            if (matches.isEmpty()) return@forEach
            val lyric = stamp.replace(line, "").trim()
            if (lyric.isEmpty()) return@forEach
            matches.forEach { m ->
                val minutes = m.groupValues[1].toLongOrNull() ?: 0L
                val seconds = m.groupValues[2].toLongOrNull() ?: 0L
                val fractionRaw = m.groupValues[3]
                val millis = when (fractionRaw.length) {
                    1 -> (fractionRaw.toLongOrNull() ?: 0L) * 100L
                    2 -> (fractionRaw.toLongOrNull() ?: 0L) * 10L
                    3 -> fractionRaw.toLongOrNull() ?: 0L
                    else -> 0L
                }
                out += LyricLine((minutes * 60L + seconds) * 1000L + millis, lyric)
            }
        }
        return out.sortedBy { it.timeMs }
    }

    fun activeIndex(lines: List<LyricLine>, positionMs: Long): Int {
        var low = 0
        var high = lines.lastIndex
        var answer = -1
        while (low <= high) {
            val mid = (low + high) ushr 1
            if (lines[mid].timeMs <= positionMs) {
                answer = mid
                low = mid + 1
            } else high = mid - 1
        }
        return answer
    }
}

/** Owns Android's device DSP effects for one ExoPlayer audio session. */
class AudioEffectsController(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("chrome_deck_dsp", Context.MODE_PRIVATE)
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var reverb: PresetReverb? = null
    private var sessionId: Int = 0

    var enabled: Boolean = prefs.getBoolean("enabled", false)
        private set
    var bassStrength: Int = prefs.getInt("bass", 650).coerceIn(0, 1000)
        private set
    var reverbPreset: Short = prefs.getInt("reverb", PresetReverb.PRESET_NONE.toInt()).toShort()
        private set

    val bassSupported: Boolean get() = bassBoost?.strengthSupported == true
    val bandCount: Int get() = equalizer?.numberOfBands?.toInt() ?: 0
    val bandRange: ShortArray get() = equalizer?.bandLevelRange ?: shortArrayOf(-1500, 1500)

    @Synchronized
    fun attach(newSessionId: Int) {
        if (newSessionId <= 0 || newSessionId == sessionId) return
        releaseEffects()
        sessionId = newSessionId
        try {
            equalizer = Equalizer(0, newSessionId).apply { enabled = this@AudioEffectsController.enabled }
            bassBoost = BassBoost(0, newSessionId).apply {
                setStrength(bassStrength.toShort())
                enabled = this@AudioEffectsController.enabled
            }
            reverb = PresetReverb(0, newSessionId).apply {
                preset = reverbPreset
                enabled = this@AudioEffectsController.enabled && reverbPreset != PresetReverb.PRESET_NONE
            }
            restoreBands()
        } catch (_: Exception) {
            releaseEffects()
        }
    }

    private fun restoreBands() {
        val eq = equalizer ?: return
        try {
            for (band in 0 until eq.numberOfBands.toInt()) {
                val saved = prefs.getInt("band_$band", 0).toShort()
                eq.setBandLevel(band.toShort(), saved.coerceIn(bandRange[0], bandRange[1]))
            }
        } catch (_: Exception) { }
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        prefs.edit().putBoolean("enabled", value).apply()
        try { equalizer?.enabled = value } catch (_: Exception) { }
        try { bassBoost?.enabled = value } catch (_: Exception) { }
        try { reverb?.enabled = value && reverbPreset != PresetReverb.PRESET_NONE } catch (_: Exception) { }
    }

    fun getBandLevel(band: Short): Int = try { equalizer?.getBandLevel(band)?.toInt() ?: 0 } catch (_: Exception) { 0 }

    fun setBandLevel(band: Short, levelMb: Int) {
        val eq = equalizer ?: return
        try {
            val safe = levelMb.coerceIn(bandRange[0].toInt(), bandRange[1].toInt()).toShort()
            eq.setBandLevel(band, safe)
            prefs.edit().putInt("band_${band.toInt()}", safe.toInt()).apply()
        } catch (_: Exception) { }
    }

    fun setBassStrength(value: Int) {
        bassStrength = value.coerceIn(0, 1000)
        prefs.edit().putInt("bass", bassStrength).apply()
        try { bassBoost?.setStrength(bassStrength.toShort()) } catch (_: Exception) { }
    }

    fun setReverb(value: Short) {
        reverbPreset = value
        prefs.edit().putInt("reverb", value.toInt()).apply()
        try {
            reverb?.preset = value
            reverb?.enabled = enabled && value != PresetReverb.PRESET_NONE
        } catch (_: Exception) { }
    }

    fun applyPreset(name: String) {
        val eq = equalizer
        if (eq != null) {
            val centers = longArrayOf(60_000L, 230_000L, 910_000L, 3_600_000L, 14_000_000L)
            val values = when (name.lowercase(Locale.US)) {
                "slowed+reverb" -> intArrayOf(450, 250, 0, 100, 180)
                "nightcore" -> intArrayOf(-100, 0, 250, 400, 500)
                "bass boost" -> intArrayOf(900, 650, 200, 0, -100)
                else -> intArrayOf(0, 0, 0, 0, 0)
            }
            try {
                val min = bandRange[0].toInt()
                val max = bandRange[1].toInt()
                for (i in centers.indices) {
                    if (eq.numberOfBands.toInt() <= 0) break
                    var nearest: Short = 0
                    var distance = Long.MAX_VALUE
                    for (b in 0 until eq.numberOfBands.toInt()) {
                        val d = abs(eq.getCenterFreq(b.toShort()).toLong() - centers[i])
                        if (d < distance) { distance = d; nearest = b.toShort() }
                    }
                    setBandLevel(nearest, values[i].coerceIn(min, max))
                }
            } catch (_: Exception) { }
        }
        when (name.lowercase(Locale.US)) {
            "slowed+reverb" -> { setBassStrength(600); setReverb(PresetReverb.PRESET_LARGEHALL) }
            "nightcore" -> { setBassStrength(100); setReverb(PresetReverb.PRESET_NONE) }
            "bass boost" -> { setBassStrength(700); setReverb(PresetReverb.PRESET_NONE) }
            else -> { setBassStrength(0); setReverb(PresetReverb.PRESET_NONE) }
        }
        setEnabled(true)
    }

    @Synchronized
    private fun releaseEffects() {
        try { equalizer?.release() } catch (_: Exception) { }
        try { bassBoost?.release() } catch (_: Exception) { }
        try { reverb?.release() } catch (_: Exception) { }
        equalizer = null; bassBoost = null; reverb = null
    }

    @Synchronized
    fun release() { releaseEffects(); sessionId = 0 }
}

data class UserPlaylist(val id: String, val name: String, val songIds: List<Long>)

class PlaylistStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("chrome_deck_playlists", Context.MODE_PRIVATE)

    fun load(): List<UserPlaylist> {
        val array = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until array.length()).mapNotNull { i ->
            try {
                val o = array.getJSONObject(i)
                val ids = o.optJSONArray("songs") ?: JSONArray()
                UserPlaylist(o.getString("id"), o.getString("name"), (0 until ids.length()).mapNotNull { ids.optLong(it).takeIf { id -> id > 0L } })
            } catch (_: Exception) { null }
        }
    }

    fun save(items: List<UserPlaylist>) {
        val array = JSONArray()
        items.forEach { p ->
            val ids = JSONArray(); p.songIds.forEach { ids.put(it) }
            array.put(JSONObject().put("id", p.id).put("name", p.name).put("songs", ids))
        }
        prefs.edit().putString("items", array.toString()).apply()
    }
}

/** Maps recognized phrases to app actions; the UI layer executes the returned action. */
object VoiceCommandParser {
    fun parse(phrase: String): String? {
        val p = phrase.trim().lowercase(Locale.US).replace(Regex("[^a-z0-9 .+_-]"), "").replace(Regex("\\s+"), " ")
        return when {
            p in setOf("play", "resume", "play music", "start music") -> "play"
            p in setOf("pause", "pause music") -> "pause"
            p in setOf("stop", "stop music") -> "stop"
            p in setOf("next", "next song", "skip") -> "next"
            p in setOf("previous", "previous song", "go back") -> "previous"
            p in setOf("shuffle", "shuffle on") -> "shuffle"
            p in setOf("restart", "restart song", "start over") -> "restart"
            p.contains("slowed") && p.contains("reverb") -> "preset:slowed+reverb"
            p.contains("nightcore") -> "preset:nightcore"
            p.contains("bass boost") -> "preset:bass boost"
            p in setOf("normal", "normal speed", "flat", "reset effects") -> "preset:normal"
            p == "show lyrics" -> "show:lyrics"
            p == "hide lyrics" -> "hide:lyrics"
            p == "show equalizer" || p == "open equalizer" -> "show:eq"
            p == "hide equalizer" -> "hide:eq"
            p == "now playing" -> "screen:nowplaying"
            p == "open songs" || p == "songs" -> "screen:songs"
            p == "open albums" || p == "albums" -> "screen:albums"
            p == "open radio" || p == "radio" -> "screen:radio"
            p == "open history" || p == "history" -> "screen:history"
            p == "open settings" || p == "settings" -> "screen:settings"
            p == "open playlists" || p == "playlists" -> "screen:playlists"
            p == "open favorites" || p == "favorites" -> "screen:favs"
            p == "open recent" || p == "recently played" -> "screen:recent"
            p == "open most played" || p == "most played" -> "screen:most"
            p == "home" || p == "go home" -> "screen:home"
            p.startsWith("play song ") -> "findsong:" + p.removePrefix("play song ").trim()
            p.startsWith("play artist ") -> "findartist:" + p.removePrefix("play artist ").trim()
            p.startsWith("play album ") -> "findalbum:" + p.removePrefix("play album ").trim()
            p.startsWith("play playlist ") -> "findplaylist:" + p.removePrefix("play playlist ").trim()
            p.startsWith("play radio ") -> "findradio:" + p.removePrefix("play radio ").trim()
            p.matches(Regex("speed [0-9]+(\\.[0-9]+)?x?")) -> "speed:" + p.removePrefix("speed ").removeSuffix("x")
            else -> null
        }
    }
}

/** Classic car-infotainment style prompt, followed by Android speech recognition. */
class ClassicVoiceAssistant(private val context: Context) {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var ready = false

    fun start(onResult: (String) -> Unit, onStatus: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onStatus("Voice recognition isn't available on this device.")
            return
        }
        if (tts == null) {
            tts = TextToSpeech(context) { status ->
                ready = status == TextToSpeech.SUCCESS
                if (ready) tts?.language = Locale.US
                speakPrompt(onResult, onStatus)
            }
        } else speakPrompt(onResult, onStatus)
    }

    private fun speakPrompt(onResult: (String) -> Unit, onStatus: (String) -> Unit) {
        onStatus("Please say a command")
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { onStatus("Listening…") }
                override fun onBeginningOfSpeech() { }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { onStatus("Processing…") }
                override fun onError(error: Int) { onStatus("I didn't catch that. Try again.") }
                override fun onResults(results: Bundle?) {
                    val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (phrase != null) onResult(phrase) else onStatus("No command heard.")
                }
                override fun onPartialResults(partialResults: Bundle?) { }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            val listen = { Handler(Looper.getMainLooper()).post { try { sr.startListening(intent) } catch (_: Exception) { onStatus("Voice recognition couldn't start.") } } }
            if (ready && tts != null) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { }
                    override fun onDone(utteranceId: String?) { listen() }
                    @Deprecated("Deprecated in Android")
                    override fun onError(utteranceId: String?) { listen() }
                })
                tts?.speak("Please say a command", TextToSpeech.QUEUE_FLUSH, null, "chrome_deck_prompt")
            } else listen()
        }
    }

    fun release() {
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
