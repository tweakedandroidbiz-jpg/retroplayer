package com.example.retroplayer

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

/** Expanded 4x2-style player widget with artwork and full playback controls. */
class ChromeDeckLargeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { ChromeDeckWidgetProvider.updateForLayout(context, manager, it, R.layout.chrome_deck_widget_large) }
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle) {
        ChromeDeckWidgetProvider.updateForLayout(context, manager, appWidgetId, R.layout.chrome_deck_widget_large)
    }
}
