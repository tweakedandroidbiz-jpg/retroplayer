package com.example.retroplayer // must match the package you chose in Android Studio

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalTime

private val Red = Color(0xFFFF2D2D)
private val Muted = Color(0xFFC4C4CC)
private val Panel = Color(0xFF1A0C0E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot(userName = "King") } // later: load the saved username
    }
}

// ---------- greetings ----------
fun greeting(): String = when (LocalTime.now().hour) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..20 -> "Good evening"
    else -> "Good night"
}

fun farewell(): String = if (LocalTime.now().hour >= 21 || LocalTime.now().hour < 5) "Good night" else "Goodbye"

fun ago(then: Long): String {
    val m = (System.currentTimeMillis() - then) / 60_000
    return when {
        m < 1 -> "Just now"
        m < 60 -> "$m min ago"
        m < 1440 -> "${m / 60} hr ago"
        m < 2880 -> "Yesterday"
        else -> "${m / 1440} days ago"
    }
}

data class Track(val title: String, val album: String, val lastPlayed: Long, val plays: Int)

fun sampleTracks(): List<Track> {
    val now = System.currentTimeMillis()
    val min = 60_000L
    return listOf(
        Track("Chrome Horizon", "Night Tapes", now - 12 * min, 41),
        Track("Slow Lane", "No album name", now - 120 * min, 48),
        Track("Midnight Static", "No album name", now - 1_600 * min, 22),
        Track("Neon Rain", "Night Tapes", now - 4_000 * min, 37),
    )
}

// ---------- screens ----------
enum class Stage { Hello, Home, Goodbye }

@Composable
fun AppRoot(userName: String) {
    var stage by remember { mutableStateOf(Stage.Hello) }
    val activity = LocalContext.current as Activity
    BackHandler(enabled = stage == Stage.Home) { stage = Stage.Goodbye }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        RedTunnel()
        when (stage) {
            Stage.Hello -> TypewriterScreen("Hello,\n$userName") { stage = Stage.Home }
            Stage.Home -> HomeScreen(userName)
            Stage.Goodbye -> TypewriterScreen(farewell()) { activity.finishAndRemoveTask() }
        }
    }
}

@Composable
fun TypewriterScreen(text: String, onDone: () -> Unit) {
    var shown by remember(text) { mutableIntStateOf(0) }
    LaunchedEffect(text) {
        for (i in 1..text.length) {
            shown = i
            delay(110)
        }
        delay(900)
        onDone()
    }
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.CenterStart) {
        Text(
            text = text.take(shown).uppercase(),
            color = Color.White,
            fontSize = 48.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 56.sp,
            style = TextStyle(shadow = Shadow(Red, blurRadius = 24f)),
        )
    }
}

@Composable
fun RedTunnel() {
    val t by rememberInfiniteTransition(label = "tunnel")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "t")
    Canvas(Modifier.fillMaxSize()) {
        val c = Offset(size.width / 2, size.height / 2)
        val left = Brush.horizontalGradient(listOf(Red.copy(alpha = 0.8f), Color.Transparent), 0f, size.width * 0.45f)
        val right = Brush.horizontalGradient(listOf(Color.Transparent, Red.copy(alpha = 0.8f)), size.width * 0.55f, size.width)
        for (i in 0..20) {
            val y = size.height * i / 20f
            drawLine(left, Offset(0f, y), c, 2f)
            drawLine(right, Offset(size.width, y), c, 2f)
        }
        for (k in 0..3) { // rings shrink toward the center = moving into the dark
            val s = 1f - ((t + k / 4f) % 1f)
            drawOval(
                color = Red.copy(alpha = s * 0.35f),
                topLeft = Offset(c.x - s * size.width * 0.8f, c.y - s * size.height * 0.5f),
                size = Size(s * size.width * 1.6f, s * size.height),
                style = Stroke(2f),
            )
        }
    }
}

@Composable
fun HomeScreen(name: String) {
    val tracks = remember { sampleTracks() }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${greeting()},", color = Muted, fontSize = 16.sp)
                Text(name, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.size(60.dp).clip(CircleShape).border(2.dp, Red, CircleShape).background(Panel))
        }
        NowPlayingMini(tracks.first())
        Section("Recently Played", tracks.sortedByDescending { it.lastPlayed }) { ago(it.lastPlayed) }
        Section("Most Played", tracks.sortedByDescending { it.plays }) { "${it.plays} plays · ${ago(it.lastPlayed)}" }
    }
}

@Composable
fun NowPlayingMini(t: Track) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).border(1.dp, Color(0xFF5A1A1D), RoundedCornerShape(18.dp))
            .background(Panel).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(80.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2C1417)))
            Column {
                Text("NOW PLAYING", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(t.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.album, color = Muted, fontSize = 13.sp)
            }
        }
        Button(
            onClick = { /* TODO: start shuffle */ },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White),
        ) { Text("Shuffle All", fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun Section(title: String, items: List<Track>, caption: (Track) -> String) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items) { t ->
                Column(Modifier.width(100.dp)) {
                    Box(Modifier.size(100.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2C1417)))
                    Text(t.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                    Text(caption(t), color = Muted, fontSize = 12.sp, maxLines = 2)
                }
            }
        }
    }
}
