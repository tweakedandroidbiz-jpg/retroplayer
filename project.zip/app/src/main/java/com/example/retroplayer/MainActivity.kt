package com.example.retroplayer

import android.Manifest
import android.app.Activity
import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioDeviceInfo
import android.media.AudioDeviceCallback
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.media3.common.AudioAttributes
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.roundToInt

const val APP_VERSION = "0.0.1.0"

private val Muted = Color(0xFFC4C4CC)
private val Panel = Color(0xFF17171B)
private val Edge = Color(0xFF2E2E35)
private val Navy = Color(0xFF0A2540)
private val NavyMuted = Color(0xFF1D4466)
private val SkyBlue = Color(0xFF0A74C2)
private val Accents = listOf(
    Color(0xFFFF2D2D), Color(0xFF3DA5FF), Color(0xFF39D353), Color(0xFFB36BFF), Color(0xFFFF9F1C),
)
val LocalAccent = compositionLocalOf { Color(0xFFFF2D2D) }
val LocalOpenPlayer = staticCompositionLocalOf<() -> Unit> { {} }

// ---------- icon outlines on a 24x24 grid ----------
private const val PLAY = "M8,5L8,19L19,12Z"
private const val PAUSE = "M6,5L10,5L10,19L6,19Z M14,5L18,5L18,19L14,19Z"
private const val NEXT = "M6,18L14.5,12L6,6Z M16,6L18,6L18,18L16,18Z"
private const val PREV = "M6,6L8,6L8,18L6,18Z M9.5,12L18,18L18,6Z"
private const val STOP = "M6,6L18,6L18,18L6,18Z"
private const val CHEVRON = "M15.4,7.4L14,6L8,12L14,18L15.4,16.6L10.8,12Z"
private const val HEART = "M12,21.35L10.55,20.03C5.4,15.36 2,12.28 2,8.5C2,5.42 4.42,3 7.5,3C9.24,3 10.91,3.81 12,5.09C13.09,3.81 14.76,3 16.5,3C19.58,3 22,5.42 22,8.5C22,12.28 18.6,15.36 13.45,20.04L12,21.35Z"
private const val SHUFFLE = "M16,3L21,3L21,8 M4,20L21,3 M21,16L21,21L16,21 M15,15L21,21 M4,4L9,9"
private const val DISC = "M2,12A10,10 0 1,0 22,12A10,10 0 1,0 2,12Z M6,12A6,6 0 1,0 18,12A6,6 0 1,0 6,12Z M9.8,12A2.2,2.2 0 1,0 14.2,12A2.2,2.2 0 1,0 9.8,12Z"
private const val NOTE = "M5,18A3,3 0 1,0 11,18A3,3 0 1,0 5,18Z M11,18L11,4C12,7.5 16,7.5 17.5,12"
private const val MIC_PERSON = "M4.5,5A2.5,2.5 0 1,0 9.5,5A2.5,2.5 0 1,0 4.5,5Z M7,7.5L7,15 M7,15L4,21 M7,15L10,21 M7,10L3.5,13 M7,10L12.5,9 M13.5,7A2.5,2.5 0 1,0 18.5,7A2.5,2.5 0 1,0 13.5,7Z M12.5,9L14,8.8"
private const val CAR = "M4,16L5.7,10.5L7.6,9L16.4,9L18.3,10.5L20,16 M3,16L21,16L21,20L3,20Z M7,18L7.01,18 M17,18L17.01,18"
private const val HEADPHONES = "M4,15L4,12A8,8 0 0,1 20,12L20,15 M3,14L7,14L7,21L3,21Z M17,14L21,14L21,21L17,21Z"
private const val BLUETOOTH = "M7,7L17,17L12,22L12,2L17,7L7,17"
private const val SPEAKER = "M4,9L4,15L8,15L13,19L13,5L8,9Z M16.5,9A4,4 0 0,1 16.5,15 M19,6.5A8,8 0 0,1 19,17.5"
private const val QMARK = "M2,12A10,10 0 1,0 22,12A10,10 0 1,0 2,12Z M9.5,9.5A2.5,2.5 0 1,1 13,11.8C12.3,12.2 12,12.7 12,13.5 M12,17L12.01,17"
private const val RADIO = "M3,8L21,8L21,20L3,20Z M7,8L17,3 M6,12L9,12 M6,16L9,16 M14.5,14A2.5,2.5 0 1,0 19.5,14A2.5,2.5 0 1,0 14.5,14Z"
private const val HOME = "M3,11L12,3L21,11L21,21L15,21L15,15L9,15L9,21L3,21Z"
private const val SONGS = "M8,6L21,6 M8,12L21,12 M8,18L21,18 M3,6L3.01,6 M3,12L3.01,12 M3,18L3.01,18"
private const val SUN = "M8,12A4,4 0 1,0 16,12A4,4 0 1,0 8,12Z M12,2L12,4 M12,20L12,22 M2,12L4,12 M20,12L22,12 M4.9,4.9L6.3,6.3 M17.7,17.7L19.1,19.1 M4.9,19.1L6.3,17.7 M17.7,6.3L19.1,4.9"
private const val CLOUD = "M7,19C4.8,19 3,17.2 3,15C3,12.9 4.6,11.2 6.7,11C7.4,8.7 9.5,7 12,7C14.8,7 17.1,9 17.5,11.6C19.5,11.8 21,13.4 21,15.5C21,17.4 19.4,19 17.5,19Z"
private const val RAIN = "M7,15C4.8,15 3,13.2 3,11C3,8.9 4.6,7.2 6.7,7C7.4,4.7 9.5,3 12,3C14.8,3 17.1,5 17.5,7.6C19.5,7.8 21,9.4 21,11.5C21,13.4 19.4,15 17.5,15Z M8,18L7,21 M12,18L11,21 M16,18L15,21"

class RetroApp : Application() {
    lateinit var player: PlayerController

    override fun onCreate() {
        super.onCreate()
        player = PlayerController(this)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val controller = (application as RetroApp).player
        setContent { AppRoot(controller) }
    }
}

// ---------- helpers ----------
fun greeting(): String = when (LocalTime.now().hour) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..20 -> "Good evening"
    else -> "Good night"
}

fun farewell(): String {
    val h = LocalTime.now().hour
    return if (h >= 21 || h < 5) "Good night" else "Goodbye"
}

fun ago(then: Long): String {
    val m = (System.currentTimeMillis() - then) / 60_000
    return when {
        m < 1 -> "just now"
        m < 60 -> "$m min ago"
        m < 1440 -> "${m / 60} hr ago"
        m < 2880 -> "yesterday"
        else -> "${m / 1440} days ago"
    }
}

fun plays(n: Long): String = if (n == 1L) "1 play" else "$n plays"

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

fun copyToFile(ctx: Context, uri: Uri, name: String) {
    ctx.contentResolver.openInputStream(uri)?.use { input ->
        File(ctx.filesDir, name).outputStream().use { out -> input.copyTo(out) }
    }
}

fun loadFileBitmap(f: File, sample: Int): ImageBitmap? {
    if (!f.exists()) return null
    return try {
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
    } catch (e: Exception) {
        null
    }
}

fun httpGet(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 8000
    c.readTimeout = 8000
    c.setRequestProperty("User-Agent", "RetroPlayer/$APP_VERSION")
    return c.inputStream.bufferedReader().use { it.readText() }
}

fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

fun isWifi(ctx: Context): Boolean {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
}

// ---------- models ----------
data class Song(
    val id: Long,
    val title: String?,
    val album: String?,
    val composer: String?,
    val artist: String?,
    val external: Boolean,
    val format: String,
    val uri: Uri,
    val albumId: Long? = null,
)

data class Station(val name: String, val url: String, val place: String, val logoUrl: String = "")
data class Weather(val tempC: Double, val code: Int, val city: String)
data class ForecastDay(val date: String, val highC: Double, val lowC: Double, val code: Int, val precipitationChance: Int)
data class WeatherAlert(val event: String, val headline: String, val severity: String, val ends: String, val description: String)
data class TravelSnapshot(
    val city: String,
    val latitude: Double,
    val longitude: Double,
    val current: Weather,
    val forecast: List<ForecastDay>,
    val alerts: List<WeatherAlert>?,
    val fetchedAt: Long,
)

private object TravelSnapshotCache {
    private var requestedCity: String = ""
    private var snapshot: TravelSnapshot? = null
    fun get(city: String): TravelSnapshot? = snapshot?.takeIf {
        requestedCity.equals(city, ignoreCase = true) && System.currentTimeMillis() - it.fetchedAt < 20 * 60_000L
    }
    fun put(city: String, value: TravelSnapshot) { requestedCity = city; snapshot = value }
}
data class Output(val kind: Int, val name: String) // 0 phone, 1 headphones, 2 bluetooth, 3 car, 4 unknown

fun String?.clean(): String? = this?.takeIf { it.isNotBlank() && it != "<unknown>" }

fun formatOf(mime: String?): String = when (mime) {
    "audio/mpeg" -> "MP3"
    "audio/flac", "audio/x-flac" -> "FLAC"
    "audio/mp4", "audio/m4a", "audio/x-m4a" -> "M4A"
    "audio/ogg", "application/ogg" -> "OGG"
    "audio/x-wav", "audio/wav" -> "WAV"
    else -> "AUDIO"
}

fun scanSongs(ctx: Context): List<Song> {
    val list = mutableListOf<Song>()
    val cols = mutableListOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.MIME_TYPE,
        MediaStore.Audio.Media.ALBUM_ID,
    )
    val hasComposer = Build.VERSION.SDK_INT >= 30
    val hasVolume = Build.VERSION.SDK_INT >= 29
    if (hasComposer) cols.add(MediaStore.Audio.Media.COMPOSER)
    if (hasVolume) cols.add(MediaStore.Audio.Media.VOLUME_NAME)
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        cols.toTypedArray(),
        "${MediaStore.Audio.Media.IS_MUSIC} != 0",
        null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC",
    )?.use { c ->
        val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val iMime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
        val iAlbumId = c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
        val iComp = if (hasComposer) c.getColumnIndex(MediaStore.Audio.Media.COMPOSER) else -1
        val iVol = if (hasVolume) c.getColumnIndex(MediaStore.Audio.Media.VOLUME_NAME) else -1
        while (c.moveToNext()) {
            val id = c.getLong(iId)
            val vol = if (iVol >= 0) c.getString(iVol) else null
            list.add(
                Song(
                    id = id,
                    title = c.getString(iTitle).clean(),
                    album = c.getString(iAlbum).clean(),
                    composer = if (iComp >= 0) c.getString(iComp).clean() else null,
                    artist = c.getString(iArtist).clean(),
                    external = vol != null && vol != "external_primary",
                    format = formatOf(c.getString(iMime)),
                    uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                    albumId = if (iAlbumId >= 0) c.getLong(iAlbumId).takeIf { it > 0L } else null,
                ),
            )
        }
    }
    return list
}

fun loadAlbumArt(ctx: Context, uri: Uri): ImageBitmap? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        val bytes = r.embeddedPicture
        if (bytes == null) {
            null
        } else {
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)?.asImageBitmap()
        }
    } catch (e: Exception) {
        null
    } finally {
        r.release()
    }
}

fun recommend(songs: List<Song>, favIds: Set<Long>, counts: Map<Long, Long>): List<Song> {
    val favs = songs.filter { it.id in favIds }
    if (favs.isEmpty()) return emptyList()
    val albums = favs.mapNotNull { it.album }.toSet()
    val composers = favs.mapNotNull { it.composer }.toSet()
    val scored = mutableListOf<Pair<Song, Int>>()
    for (s in songs) {
        if (s.id in favIds) continue
        var score = 0
        val a = s.album
        if (a != null && a in albums) score += 3
        val c = s.composer
        if (c != null && c in composers) score += 2
        score += minOf((counts[s.id] ?: 0L).toInt(), 5)
        if (score > 0) scored.add(s to score)
    }
    return scored.sortedByDescending { it.second }.take(15).map { it.first }
}

// ---------- online: weather, lyrics, radio ----------
suspend fun fetchWeather(city: String): Weather? = withContext(Dispatchers.IO) {
    try {
        val geo = JSONObject(httpGet("https://geocoding-api.open-meteo.com/v1/search?name=${enc(city)}&count=1"))
        val r = geo.getJSONArray("results").getJSONObject(0)
        val lat = r.getDouble("latitude")
        val lon = r.getDouble("longitude")
        val name = r.optString("name", city)
        val w = JSONObject(httpGet("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"))
        val cur = w.getJSONObject("current")
        Weather(cur.getDouble("temperature_2m"), cur.getInt("weather_code"), name)
    } catch (e: Exception) {
        null
    }
}

private fun nwsGet(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 8000
    c.readTimeout = 8000
    c.setRequestProperty("User-Agent", "ChromeDeck/${APP_VERSION} (Android automotive infotainment app)")
    c.setRequestProperty("Accept", "application/geo+json")
    return c.inputStream.bufferedReader().use { it.readText() }
}

suspend fun fetchTravelSnapshot(city: String): TravelSnapshot? = withContext(Dispatchers.IO) {
    try {
        val geo = JSONObject(httpGet("https://geocoding-api.open-meteo.com/v1/search?name=${enc(city)}&count=1&language=en&format=json"))
        val places = geo.optJSONArray("results") ?: return@withContext null
        if (places.length() == 0) return@withContext null
        val place = places.getJSONObject(0)
        val lat = place.getDouble("latitude")
        val lon = place.getDouble("longitude")
        val resolvedCity = place.optString("name", city)
        val forecastUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&forecast_days=5&timezone=auto"
        val root = JSONObject(httpGet(forecastUrl))
        val currentJson = root.getJSONObject("current")
        val daily = root.getJSONObject("daily")
        val dates = daily.getJSONArray("time")
        val highs = daily.getJSONArray("temperature_2m_max")
        val lows = daily.getJSONArray("temperature_2m_min")
        val codes = daily.getJSONArray("weather_code")
        val rain = daily.optJSONArray("precipitation_probability_max")
        val days = (0 until dates.length()).map { i ->
            ForecastDay(
                date = dates.optString(i),
                highC = highs.optDouble(i),
                lowC = lows.optDouble(i),
                code = codes.optInt(i),
                precipitationChance = rain?.optInt(i, 0) ?: 0,
            )
        }
        val alerts: List<WeatherAlert>? = try {
            val alertRoot = JSONObject(nwsGet("https://api.weather.gov/alerts/active?point=$lat,$lon"))
            val features = alertRoot.optJSONArray("features") ?: JSONArray()
            (0 until features.length()).mapNotNull { i ->
                val props = features.optJSONObject(i)?.optJSONObject("properties") ?: return@mapNotNull null
                WeatherAlert(
                    event = props.optString("event", "Weather alert"),
                    headline = props.optString("headline", props.optString("event", "Weather alert")),
                    severity = props.optString("severity", "Unknown"),
                    ends = props.optString("ends", props.optString("expires", "")),
                    description = props.optString("description", "").take(900),
                )
            }.take(8)
        } catch (_: Exception) { null }
        TravelSnapshot(
            city = resolvedCity,
            latitude = lat,
            longitude = lon,
            current = Weather(currentJson.getDouble("temperature_2m"), currentJson.getInt("weather_code"), resolvedCity),
            forecast = days,
            alerts = alerts,
            fetchedAt = System.currentTimeMillis(),
        )
    } catch (_: Exception) { null }
}

fun loadWeather(p: SharedPreferences): Weather? {
    if (!p.contains("w_city")) return null
    return Weather(p.getFloat("w_temp", 0f).toDouble(), p.getInt("w_code", 0), p.getString("w_city", "") ?: "")
}

fun saveWeather(p: SharedPreferences, w: Weather) {
    p.edit().putFloat("w_temp", w.tempC.toFloat()).putInt("w_code", w.code).putString("w_city", w.city).apply()
}

fun weatherIcon(code: Int): String = when {
    code <= 1 -> SUN
    code in 51..67 || code in 80..82 || code >= 95 -> RAIN
    else -> CLOUD
}

suspend fun fetchLyrics(title: String, artist: String): String? = withContext(Dispatchers.IO) {
    try {
        val arr = JSONArray(httpGet("https://lrclib.net/api/search?track_name=${enc(title)}&artist_name=${enc(artist)}"))
        if (arr.length() == 0) {
            null
        } else {
            val first = arr.getJSONObject(0)
            val synced = first.optString("syncedLyrics", "")
            val plain = first.optString("plainLyrics", "")
            val t = if (synced.isNotBlank() && synced != "null") synced else plain
            if (t.isBlank() || t == "null") null else t
        }
    } catch (e: Exception) {
        null
    }
}

suspend fun searchStations(q: String): List<Station> = withContext(Dispatchers.IO) {
    val out = LinkedHashMap<String, Station>()
    for (param in listOf("name", "state")) {
        try {
            val arr = JSONArray(
                httpGet("https://de1.api.radio-browser.info/json/stations/search?$param=${enc(q)}&limit=25&hidebroken=true&order=clickcount&reverse=true"),
            )
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val url = o.optString("url_resolved")
                if (url.isNotBlank() && !out.containsKey(url)) {
                    val place = listOf(o.optString("state"), o.optString("country")).filter { it.isNotBlank() }.joinToString(", ")
                    out[url] = Station(o.optString("name").trim().ifBlank { "Radio station" }, url, place, o.optString("favicon").takeIf { it.startsWith("http") }.orEmpty())
                }
            }
        } catch (e: Exception) {
            // ignore and keep what we have
        }
    }
    out.values.toList()
}

suspend fun fetchPopularStations(): List<Station> = withContext(Dispatchers.IO) {
    try {
        val arr = JSONArray(httpGet("https://de1.api.radio-browser.info/json/stations/topclick/12"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val url = o.optString("url_resolved")
            if (url.isBlank()) null else Station(o.optString("name").trim().ifBlank { "Radio station" }, url, listOf(o.optString("state"), o.optString("country")).filter { it.isNotBlank() }.joinToString(", "), o.optString("favicon").takeIf { it.startsWith("http") }.orEmpty())
        }
    } catch (_: Exception) { emptyList() }
}

fun radioLines(st: Station, icy: String?): Triple<String, String, String> {
    val place = st.place.ifBlank { "FM Radio" }
    if (icy == null) return Triple(st.name, "Live radio", place)
    val i = icy.indexOf(" - ")
    return if (i > 0) Triple(st.name, icy.substring(i + 3).trim(), icy.substring(0, i).trim()) else Triple(st.name, icy.trim(), place)
}

suspend fun fetchItunesArtBytes(title: String, artist: String): ByteArray? = withContext(Dispatchers.IO) {
    if (title.isBlank() || artist.isBlank()) return@withContext null
    try {
        val query = "$title $artist"
        val json = JSONObject(httpGet("https://itunes.apple.com/search?term=${enc(query)}&entity=song&limit=10"))
        val results = json.optJSONArray("results") ?: return@withContext null
        fun normal(value: String) = value.lowercase().replace(Regex("[^a-z0-9]"), "")
        val wantedTitle = normal(title)
        val wantedArtist = normal(artist)
        var artworkUrl = ""
        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val foundTitle = normal(item.optString("trackName"))
            val foundArtist = normal(item.optString("artistName"))
            val titleMatch = foundTitle == wantedTitle || foundTitle.contains(wantedTitle) || wantedTitle.contains(foundTitle)
            val artistMatch = foundArtist == wantedArtist || foundArtist.contains(wantedArtist) || wantedArtist.contains(foundArtist)
            if (titleMatch && artistMatch) {
                artworkUrl = item.optString("artworkUrl100").replace("100x100", "600x600")
                break
            }
        }
        if (artworkUrl.isBlank()) return@withContext null
        val connection = URL(artworkUrl).openConnection() as HttpURLConnection
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.setRequestProperty("User-Agent", "ChromeDeck/$APP_VERSION")
        connection.inputStream.use { it.readBytes().takeIf { bytes -> bytes.size in 1..3_000_000 } }
    } catch (_: Exception) {
        null
    }
}

private fun radioFallbackBitmap(): ImageBitmap {
    val bitmap = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    canvas.drawColor(android.graphics.Color.rgb(8, 28, 48))
    paint.color = android.graphics.Color.rgb(15, 93, 145)
    canvas.drawRoundRect(RectF(38f, 38f, 474f, 474f), 58f, 58f, paint)
    paint.color = android.graphics.Color.rgb(7, 31, 52)
    canvas.drawRoundRect(RectF(82f, 118f, 430f, 398f), 34f, 34f, paint)
    paint.color = android.graphics.Color.rgb(80, 190, 255)
    paint.style = Paint.Style.STROKE
    paint.strokeWidth = 15f
    canvas.drawCircle(256f, 254f, 93f, paint)
    canvas.drawArc(RectF(115f, 115f, 397f, 397f), 220f, 100f, false, paint)
    canvas.drawArc(RectF(155f, 155f, 357f, 357f), 220f, 100f, false, paint)
    paint.style = Paint.Style.FILL
    paint.color = android.graphics.Color.WHITE
    canvas.drawCircle(256f, 254f, 17f, paint)
    paint.textAlign = Paint.Align.CENTER
    paint.textSize = 36f
    paint.typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
    canvas.drawText("CHROME DECK", 256f, 448f, paint)
    return bitmap.asImageBitmap()
}

data class HistoryEntry(val at: Long, val source: String, val text: String)

// ---------- audio output detection ----------
private val CAR_LONG = listOf(
    "uconnect", "toyota", "mazda", "chevy", "chevrolet", "hyundai", "nissan", "pioneer", "kenwood", "alpine",
    "sony xav", "stereo", "bt audio", "motors", "subaru", "lexus", "mercedes", "volvo", "tesla", "carplay", "head unit",
)
private val CAR_WORDS = listOf("kia", "honda", "ford", "dodge", "jeep", "car", "auto", "gmc", "bmw", "audi", "vw", "sync")
private val PHONE_WORDS = listOf("buds", "pods", "headphone", "earbud", "earphone", "headset", "wh-", "wf-", "airpods")

fun isCarName(n: String): Boolean {
    val l = n.lowercase()
    val words = l.split(Regex("[^a-z0-9]+"))
    return CAR_LONG.any { l.contains(it) } || CAR_WORDS.any { it in words }
}

fun readOutput(ctx: Context): Output {
    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val devs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
    fun nameOf(d: AudioDeviceInfo): String = d.productName?.toString()?.trim().orEmpty()
    val bus = devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUS }
    if (bus != null) return Output(3, nameOf(bus).ifBlank { "Car audio" })
    val bt = devs.firstOrNull {
        it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
            (Build.VERSION.SDK_INT >= 31 && (it.type == AudioDeviceInfo.TYPE_BLE_HEADSET || it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER))
    }
    if (bt != null) {
        val n = nameOf(bt).ifBlank { "Bluetooth audio" }
        val l = n.lowercase()
        val kind = if (isCarName(n)) 3 else if (PHONE_WORDS.any { l.contains(it) }) 1 else 2
        return Output(kind, n)
    }
    val wired = devs.firstOrNull {
        it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            it.type == AudioDeviceInfo.TYPE_USB_HEADSET
    }
    if (wired != null) return Output(1, "Wired headphones")
    if (devs.any { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }) return Output(0, "Phone speaker")
    return Output(4, "Unknown output")
}

fun outputIcon(kind: Int): String = when (kind) {
    0 -> SPEAKER
    1 -> HEADPHONES
    2 -> BLUETOOTH
    3 -> CAR
    else -> QMARK
}

// ---------- player ----------
class PlayerController(ctx: Context) {
    private val appCtx = ctx.applicationContext
    private val prefs = ctx.getSharedPreferences("retro", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + kotlinx.coroutines.Dispatchers.Main)
    private val artCache = HashMap<String, ImageBitmap?>()
    @Volatile var librarySongs: List<Song> = emptyList()
    private val playlistStore = PlaylistStore(ctx)
    val audioEffects = AudioEffectsController(ctx)
    var playlists by mutableStateOf(playlistStore.load())
    var upNext by mutableStateOf<List<Song>>(emptyList())
    var radioSearches by mutableStateOf((prefs.getString("radio_searches", "") ?: "").split("\n").filter { it.isNotBlank() }.take(10))
    val exo: ExoPlayer = ExoPlayer.Builder(ctx)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true,
        )
        .setWakeMode(C.WAKE_MODE_NETWORK)
        .setHandleAudioBecomingNoisy(true)
        .build()

    var current by mutableStateOf<Song?>(null)
    var station by mutableStateOf<Station?>(null)
    var icyTitle by mutableStateOf<String?>(null)
    var playing by mutableStateOf(false)
    var shuffleOn by mutableStateOf(false)
    var speed by mutableFloatStateOf(prefs.getFloat("speed", 1f))
    var pitchLock by mutableStateOf(prefs.getBoolean("pitchLock", false))
    var counts by mutableStateOf(loadLongMap("count_"))
    var lastPlayed by mutableStateOf(loadLongMap("last_"))
    var favorites by mutableStateOf(
        (prefs.getStringSet("fav", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet(),
    )
    var presets by mutableStateOf(loadPresets())
    var history by mutableStateOf(loadHistory())
    var radioArt by mutableStateOf<ImageBitmap?>(null)
    private var queue: List<Song> = emptyList()
    private var userPaused = false
    private var resumeOnCarConnect = false
    private val audioManager = appCtx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            if (removedDevices.any { it.type == AudioDeviceInfo.TYPE_BUS || isCarName(it.productName?.toString().orEmpty()) } && exo.isPlaying) {
                resumeOnCarConnect = true
            }
        }
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            val carConnected = addedDevices.any { it.type == AudioDeviceInfo.TYPE_BUS || isCarName(it.productName?.toString().orEmpty()) }
            if (carConnected && resumeOnCarConnect && !userPaused && hasPlayback) {
                resumeOnCarConnect = false
                exo.play()
            }
        }
    }

    val hasPlayback: Boolean get() = current != null || station != null

    init {
        applySpeed()
        audioEffects.attach(exo.audioSessionId)
        audioManager.registerAudioDeviceCallback(deviceCallback, Handler(Looper.getMainLooper()))
        exo.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioSessionIdChanged(
                eventTime: AnalyticsListener.EventTime,
                audioSessionId: Int
            ) {
                audioEffects.attach(audioSessionId)
            }
        })
        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
                ChromeDeckWidgetProvider.refresh(appCtx)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val mediaId = mediaItem?.mediaId ?: return
                if (mediaId.startsWith("radio|")) {
                    val streamUrl = mediaId.removePrefix("radio|")
                    val metadataName = mediaItem.mediaMetadata.title?.toString().orEmpty()
                    val activeStation = presets.firstOrNull { it.url == streamUrl }
                        ?: Station(metadataName.ifBlank { "Radio station" }, streamUrl, "")
                    station = activeStation
                    current = null
                    icyTitle = null
                    radioArt = cachedRadioArt("station:${activeStation.url}") ?: radioFallbackBitmap()
                    scope.launch { loadStationArtwork(activeStation) }
                    ChromeDeckWidgetProvider.refresh(appCtx)
                    return
                }
                val id = mediaId.substringAfterLast('|').toLongOrNull() ?: mediaId.toLongOrNull() ?: return
                station = null
                current = queue.firstOrNull { it.id == id } ?: librarySongs.firstOrNull { it.id == id }
                refreshUpNext()
                record(id)
                ChromeDeckWidgetProvider.refresh(appCtx)
            }

            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                val s = station ?: return
                val raw = mediaMetadata.title?.toString()
                val t = if (raw != null && raw != s.name) raw else null
                if (t != icyTitle) {
                    icyTitle = t
                    if (t != null) onRadioTrack(s, t)
                    ChromeDeckWidgetProvider.refresh(appCtx)
                }
            }
        })
    }

    private fun loadLongMap(prefix: String): Map<Long, Long> {
        val out = mutableMapOf<Long, Long>()
        for ((k, v) in prefs.all) {
            if (k.startsWith(prefix) && v is Long) {
                val id = k.removePrefix(prefix).toLongOrNull()
                if (id != null) out[id] = v
            }
        }
        return out
    }

    private fun loadPresets(): List<Station> {
        val out = mutableListOf<Station>()
        for (line in (prefs.getString("presets", "") ?: "").split("\n")) {
            val p = line.split("\t")
            if (p.size >= 3 && p[1].isNotBlank()) out.add(Station(p[0], p[1], p[2], p.getOrNull(3).orEmpty()))
        }
        return out
    }

    private fun loadHistory(): List<HistoryEntry> {
        val out = mutableListOf<HistoryEntry>()
        for (line in (prefs.getString("history", "") ?: "").split("\n")) {
            val p = line.split("\t")
            val at = p.getOrNull(0)?.toLongOrNull()
            if (p.size >= 3 && at != null) out.add(HistoryEntry(at, p[1], p[2]))
        }
        return out
    }

    private fun addHistory(source: String, text: String) {
        if (text.isBlank() || history.firstOrNull()?.text == text) return
        val e = HistoryEntry(System.currentTimeMillis(), source.replace("\t", " "), text.replace("\t", " ").replace("\n", " "))
        history = (listOf(e) + history).take(200)
        prefs.edit().putString("history", history.joinToString("\n") { "${it.at}\t${it.source}\t${it.text}" }).apply()
    }

    private fun cacheFile(key: String): File {
        val digest = MessageDigest.getInstance("SHA-256").digest(key.toByteArray())
            .joinToString("") { "%02x".format(it) }
        val dir = File(appCtx.filesDir, "radio_art_cache").apply { mkdirs() }
        return File(dir, "$digest.jpg")
    }

    private fun cachedRadioArt(key: String): ImageBitmap? {
        val file = cacheFile(key)
        if (!file.exists()) return null
        file.setLastModified(System.currentTimeMillis())
        return try { BitmapFactory.decodeFile(file.path)?.asImageBitmap() } catch (_: Exception) { null }
    }

    private fun saveRadioArt(key: String, bytes: ByteArray): ImageBitmap? {
        if (bytes.isEmpty() || bytes.size > 3_000_000) return null
        return try {
            val file = cacheFile(key)
            file.writeBytes(bytes)
            trimRadioArtCache()
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        } catch (_: Exception) { null }
    }

    private fun trimRadioArtCache() {
        val dir = File(appCtx.filesDir, "radio_art_cache")
        val files = dir.listFiles()?.filter { it.isFile }?.sortedBy { it.lastModified() } ?: return
        var total = files.sumOf { it.length() }
        for (file in files) {
            if (total <= 24L * 1024L * 1024L) break
            total -= file.length()
            file.delete()
        }
    }

    private suspend fun downloadImage(url: String, key: String): ImageBitmap? = withContext(Dispatchers.IO) {
        try {
            if (!url.startsWith("https://") && !url.startsWith("http://")) return@withContext null
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.connectTimeout = 7000
            connection.readTimeout = 7000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("User-Agent", "ChromeDeck/$APP_VERSION")
            val bytes = connection.inputStream.use { it.readBytes().takeIf { data -> data.size in 1..3_000_000 } }
                ?: return@withContext null
            saveRadioArt(key, bytes)
        } catch (_: Exception) { null }
    }

    private suspend fun loadStationArtwork(s: Station): ImageBitmap {
        val key = "station:${s.url}"
        cachedRadioArt(key)?.let { art ->
            if (station?.url == s.url && icyTitle == null) radioArt = art
            return art
        }
        val direct = s.logoUrl.takeIf { it.isNotBlank() }
        val directArt = direct?.let { downloadImage(it, key) }
        val stationLookupLogo = if (directArt == null) withContext(Dispatchers.IO) {
            try {
                val found = JSONArray(httpGet("https://de1.api.radio-browser.info/json/stations/search?name=${enc(s.name)}&limit=8&hidebroken=true"))
                (0 until found.length()).asSequence()
                    .mapNotNull { found.optJSONObject(it)?.optString("favicon") }
                    .firstOrNull { it.startsWith("https://") || it.startsWith("http://") }
            } catch (_: Exception) { null }
        } else null
        val host = try { URL(s.url).host } catch (_: Exception) { "" }
        val fallback = host.takeIf { it.isNotBlank() }?.let { "https://www.google.com/s2/favicons?domain_url=${enc("https://$it")}&sz=256" }
        val art = directArt
            ?: (stationLookupLogo?.let { downloadImage(it, key) })
            ?: (fallback?.let { downloadImage(it, key) })
            ?: radioFallbackBitmap()
        if (station?.url == s.url && icyTitle == null) radioArt = art
        ChromeDeckWidgetProvider.refresh(appCtx)
        return art
    }

    private fun onRadioTrack(s: Station, raw: String) {
        addHistory(s.name, raw)
        val split = raw.split(" - ", limit = 2)
        val artist = split.firstOrNull().orEmpty().trim()
        val title = split.getOrNull(1)?.trim().orEmpty()
        val trackKey = "track:${artist.lowercase()}|${title.lowercase()}"
        cachedRadioArt(trackKey)?.let {
            artCache[raw] = it
            if (icyTitle == raw) radioArt = it
            ChromeDeckWidgetProvider.refresh(appCtx)
            return
        }
        scope.launch {
            var art: ImageBitmap? = null
            if (artist.isNotBlank() && title.isNotBlank()) {
                val bytes = fetchItunesArtBytes(title, artist)
                if (bytes != null) art = saveRadioArt(trackKey, bytes)
            }
            if (art == null) art = loadStationArtwork(s)
            artCache[raw] = art
            if (icyTitle == raw) radioArt = art ?: radioFallbackBitmap()
            ChromeDeckWidgetProvider.refresh(appCtx)
        }
        ChromeDeckWidgetProvider.refresh(appCtx)
    }

    private fun startPlaybackService() {
        try {
            appCtx.startService(Intent(appCtx, ChromeDeckAutoService::class.java))
        } catch (e: Exception) {
            // playback still works while the app is open
        }
    }

    private fun record(id: Long) {
        val n = (counts[id] ?: 0L) + 1
        val now = System.currentTimeMillis()
        prefs.edit().putLong("count_$id", n).putLong("last_$id", now).apply()
        counts = counts + (id to n)
        lastPlayed = lastPlayed + (id to now)
        val s = current
        if (s != null) addHistory("Local", "${s.title ?: "No song name"} - ${s.artist ?: s.composer ?: "Unknown Artist"}")
    }

    fun play(list: List<Song>, startIndex: Int) {
        if (list.isEmpty()) return
        userPaused = false
        resumeOnCarConnect = false
        queue = list.toList()
        refreshUpNext(startIndex)
        station = null
        icyTitle = null
        radioArt = null
        applySpeed()
        exo.setMediaItems(
            list.map {
                MediaItem.Builder()
                    .setMediaId(it.id.toString())
                    .setUri(it.uri)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(it.title ?: "No song name")
                            .setArtist(it.artist ?: it.composer ?: "Unknown Artist")
                            .setAlbumTitle(it.album ?: "No album name")
                            .setArtworkUri(it.albumId?.let { albumId -> Uri.parse("content://media/external/audio/albumart/$albumId") })
                            .build(),
                    )
                    .build()
            },
            startIndex,
            0L,
        )
        exo.prepare()
        exo.play()
        startPlaybackService()
        ChromeDeckWidgetProvider.refresh(appCtx)
    }

    private fun mediaItemFor(song: Song): MediaItem = MediaItem.Builder()
        .setMediaId(song.id.toString()).setUri(song.uri)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(song.title ?: "No song name")
                .setArtist(song.artist ?: song.composer ?: "Unknown Artist")
                .setAlbumTitle(song.album ?: "No album name")
                .setArtworkUri(song.albumId?.let { Uri.parse("content://media/external/audio/albumart/$it") })
                .build(),
        )
        .build()

    private fun refreshUpNext(fromIndex: Int = exo.currentMediaItemIndex) {
        val start = (fromIndex + 1).coerceAtLeast(0)
        upNext = queue.drop(start)
    }

    fun queueNext(song: Song) {
        if (current == null || station != null || exo.currentMediaItemIndex < 0) { play(listOf(song), 0); return }
        if (shuffleOn) { shuffleOn = false; exo.shuffleModeEnabled = false }
        val insertAt = (exo.currentMediaItemIndex + 1).coerceIn(0, queue.size)
        queue = queue.toMutableList().apply { add(insertAt, song) }
        exo.addMediaItem(insertAt, mediaItemFor(song))
        refreshUpNext()
    }

    fun playQueued(index: Int) {
        val absolute = exo.currentMediaItemIndex + 1 + index
        if (absolute in queue.indices) exo.seekTo(absolute, 0L)
    }

    fun removeQueued(index: Int) {
        val absolute = exo.currentMediaItemIndex + 1 + index
        if (absolute in queue.indices) {
            queue = queue.toMutableList().apply { removeAt(absolute) }
            exo.removeMediaItem(absolute)
            refreshUpNext()
        }
    }

    fun clearUpNext() {
        val start = exo.currentMediaItemIndex + 1
        if (start >= 0 && start < queue.size) {
            exo.removeMediaItems(start, queue.size)
            queue = queue.take(start)
            refreshUpNext()
        }
    }

    fun createPlaylist(name: String) {
        val clean = name.trim().take(40)
        if (clean.isBlank()) return
        playlists = playlists + UserPlaylist(java.util.UUID.randomUUID().toString(), clean, emptyList())
        playlistStore.save(playlists)
    }

    fun renamePlaylist(id: String, name: String) {
        val clean = name.trim().take(40)
        if (clean.isBlank()) return
        playlists = playlists.map { if (it.id == id) it.copy(name = clean) else it }
        playlistStore.save(playlists)
    }

    fun deletePlaylist(id: String) {
        playlists = playlists.filterNot { it.id == id }
        playlistStore.save(playlists)
    }

    fun addToPlaylist(id: String, song: Song) {
        playlists = playlists.map { p -> if (p.id == id && song.id !in p.songIds) p.copy(songIds = p.songIds + song.id) else p }
        playlistStore.save(playlists)
    }

    fun removeFromPlaylist(id: String, songId: Long) {
        playlists = playlists.map { p -> if (p.id == id) p.copy(songIds = p.songIds - songId) else p }
        playlistStore.save(playlists)
    }

    fun playPlaylist(id: String, allSongs: List<Song>, shuffle: Boolean = false) {
        val ids = playlists.firstOrNull { it.id == id }?.songIds ?: return
        val found = ids.mapNotNull { idValue -> allSongs.firstOrNull { it.id == idValue } }
        if (found.isNotEmpty()) play(if (shuffle) found.shuffled() else found, 0)
    }

    fun applyAudioPreset(name: String) {
        audioEffects.applyPreset(name)
        when (name.lowercase()) {
            "slowed+reverb" -> setSpeedValue(0.84f)
            "nightcore" -> setSpeedValue(1.24f)
            else -> setSpeedValue(1f)
        }
    }

    fun shuffleAll(all: List<Song>) = play(all.shuffled(), 0)

    fun rememberRadioSearch(query: String) {
        val q = query.trim()
        if (q.isBlank()) return
        radioSearches = (listOf(q) + radioSearches.filterNot { it.equals(q, true) }).take(10)
        prefs.edit().putString("radio_searches", radioSearches.joinToString("\n")).apply()
    }

    fun removeRadioSearch(query: String) {
        radioSearches = radioSearches.filterNot { it == query }
        prefs.edit().putString("radio_searches", radioSearches.joinToString("\n")).apply()
    }

    fun clearRadioSearches() {
        radioSearches = emptyList()
        prefs.edit().remove("radio_searches").apply()
    }

    fun playStation(s: Station) {
        userPaused = false
        resumeOnCarConnect = false
        queue = emptyList()
        upNext = emptyList()
        current = null
        station = s
        icyTitle = null
        radioArt = cachedRadioArt("station:${s.url}") ?: radioFallbackBitmap()
        scope.launch { loadStationArtwork(s) }
        applySpeed()
        exo.setMediaItem(
            MediaItem.Builder()
                .setMediaId("radio|${s.url}")
                .setUri(s.url)
                .setMediaMetadata(
                    MediaMetadata.Builder().setTitle(s.name).setArtist("FM Radio")
                        .setArtworkUri(
                            (s.logoUrl.takeIf { it.isNotBlank() } ?: try {
                                val host = URL(s.url).host
                                "https://www.google.com/s2/favicons?domain_url=${enc("https://$host")}&sz=256"
                            } catch (_: Exception) { null })?.let(Uri::parse),
                        ).build(),
                )
                .build(),
        )
        exo.prepare()
        exo.play()
        startPlaybackService()
        ChromeDeckWidgetProvider.refresh(appCtx)
    }

    fun shutdown() {
        stop()
        try {
            appCtx.stopService(Intent(appCtx, ChromeDeckAutoService::class.java))
        } catch (e: Exception) {
            // nothing to stop
        }
    }

    fun toggle() {
        if (exo.isPlaying) pauseByUser() else playByUser()
    }

    fun pauseByUser() { userPaused = true; exo.pause() }
    fun playByUser() { userPaused = false; resumeOnCarConnect = false; exo.play() }

    fun next() = exo.seekToNext()
    fun previous() = exo.seekToPrevious()

    fun stop() {
        userPaused = true
        resumeOnCarConnect = false
        exo.stop()
        exo.clearMediaItems()
        current = null
        station = null
        upNext = emptyList()
        queue = emptyList()
        icyTitle = null
        playing = false
        ChromeDeckWidgetProvider.refresh(appCtx)
    }

    fun toggleShuffle() {
        shuffleOn = !shuffleOn
        exo.shuffleModeEnabled = shuffleOn
    }

    private fun applySpeed() {
        exo.playbackParameters = PlaybackParameters(speed, if (pitchLock) 1f else speed)
    }

    fun setSpeedValue(v: Float) {
        speed = v.coerceIn(0.25f, 4f)
        prefs.edit().putFloat("speed", speed).apply()
        applySpeed()
    }

    fun setPitchLockValue(b: Boolean) {
        pitchLock = b
        prefs.edit().putBoolean("pitchLock", b).apply()
        applySpeed()
    }

    fun toggleFav(id: Long) {
        favorites = if (id in favorites) favorites - id else favorites + id
        prefs.edit().putStringSet("fav", favorites.map { it.toString() }.toSet()).apply()
    }

    fun togglePreset(s: Station) {
        presets = if (presets.any { it.url == s.url }) {
            presets.filter { it.url != s.url }
        } else {
            (presets + s).takeLast(6)
        }
        prefs.edit().putString(
            "presets",
            presets.joinToString("\n") { "${it.name.replace("\t", " ")}\t${it.url}\t${it.place.replace("\t", " ")}\t${it.logoUrl.replace("\t", " ")}" },
        ).apply()
    }

    fun lyricsFor(id: Long): String? = prefs.getString("lyr_$id", null)

    fun saveLyrics(id: Long, text: String) {
        if (text.isBlank()) prefs.edit().remove("lyr_$id").apply() else prefs.edit().putString("lyr_$id", text).apply()
    }

    fun release() { audioManager.unregisterAudioDeviceCallback(deviceCallback); audioEffects.release(); exo.release() }
}

// ---------- root ----------
enum class Stage { Hello, Home, Goodbye }
enum class Screen { Home, Songs, Albums, Album, Radio, Travel, History, Recent, Most, Favs, Playlists, Queue, Settings, NowPlaying }
data class SongItem(val song: Song, val note: String?)
data class SongSection(val title: String?, val items: List<SongItem>, val empty: String)

@Composable
fun AppRoot(player: PlayerController) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("retro", Context.MODE_PRIVATE) }
    var name by remember { mutableStateOf(prefs.getString("name", "") ?: "") }
    var tagline by remember { mutableStateOf(prefs.getString("tagline", "") ?: "") }
    var accentIdx by remember { mutableIntStateOf(prefs.getInt("accent", 0)) }
    var dim by remember { mutableFloatStateOf(prefs.getFloat("dim", 0.5f)) }
    var city by remember { mutableStateOf(prefs.getString("city", "") ?: "") }
    var fahrenheit by remember { mutableStateOf(prefs.getBoolean("fahrenheit", true)) }
    var sdArt by remember { mutableStateOf(prefs.getBoolean("sdArt", true)) }
    var keepScreenAwakeInDrive by remember { mutableStateOf(prefs.getBoolean("keepScreenAwakeInDrive", true)) }
    var weather by remember { mutableStateOf(loadWeather(prefs)) }
    var profilePic by remember { mutableStateOf(loadFileBitmap(File(ctx.filesDir, "profile.jpg"), 4)) }
    var bgPic by remember { mutableStateOf(loadFileBitmap(File(ctx.filesDir, "bg.jpg"), 2)) }
    var stage by remember { mutableStateOf(Stage.Hello) }
    var screen by remember { mutableStateOf(Screen.Home) }
    var returnTo by remember { mutableStateOf(Screen.Home) }
    var albumName by remember { mutableStateOf("") }
    var askingName by remember { mutableStateOf(false) }
    val activity = ctx as Activity

    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) }
    val askPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(stage) {
        if (stage == Stage.Home && Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    LaunchedEffect(granted) {
        if (granted) {
            songs = withContext(Dispatchers.IO) { scanSongs(ctx) }
            player.librarySongs = songs
        } else {
            player.librarySongs = emptyList()
        }
    }

    LaunchedEffect(city) {
        while (city.isNotBlank()) {
            val w = fetchWeather(city)
            if (w != null) {
                weather = w
                saveWeather(prefs, w)
            }
            delay(15 * 60_000L)
        }
    }

    val pickProfile = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            copyToFile(ctx, uri, "profile.jpg")
            profilePic = loadFileBitmap(File(ctx.filesDir, "profile.jpg"), 4)
        }
    }
    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            copyToFile(ctx, uri, "bg.jpg")
            bgPic = loadFileBitmap(File(ctx.filesDir, "bg.jpg"), 2)
        }
    }

    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val ready = stage == Stage.Home && name.isNotBlank() && !askingName
    val driving = landscape && ready && player.hasPlayback
    LaunchedEffect(driving, keepScreenAwakeInDrive) {
        if (driving && keepScreenAwakeInDrive) activity.window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else activity.window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // rotating into landscape while music plays switches to Drive Mode
    LaunchedEffect(landscape, player.hasPlayback) {
        if (landscape && player.hasPlayback && screen != Screen.NowPlaying) {
            returnTo = screen
            screen = Screen.NowPlaying
        }
    }

    BackHandler(enabled = stage == Stage.Home) {
        when {
            askingName -> askingName = false
            screen == Screen.NowPlaying -> screen = if (returnTo == Screen.NowPlaying) Screen.Home else returnTo
            screen == Screen.Album -> screen = Screen.Albums
            screen != Screen.Home -> screen = Screen.Home
            else -> {
                player.shutdown()
                stage = Stage.Goodbye
            }
        }
    }

    val openPlayer: () -> Unit = {
        if (screen != Screen.NowPlaying) returnTo = screen
        screen = Screen.NowPlaying
    }

    val accent = Accents[accentIdx]
    CompositionLocalProvider(LocalAccent provides accent, LocalOpenPlayer provides openPlayer) {
        MaterialTheme(colorScheme = darkColorScheme(primary = accent)) {
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                if (screen == Screen.NowPlaying && !landscape && ready) SkyBackdrop() else Backdrop(bgPic, dim)

                val content: @Composable () -> Unit = {
                    when (screen) {
                        Screen.Home -> HomeScreen(
                            name = name,
                            tagline = tagline,
                            profilePic = profilePic,
                            songs = songs,
                            granted = granted,
                            onAskPermission = { askPerm.launch(perm) },
                            player = player,
                            onOpen = { screen = it },
                        )
                        Screen.Songs -> SongsScreen(songs, player)
                        Screen.Albums -> AlbumsScreen(songs) {
                            albumName = it
                            screen = Screen.Album
                        }
                        Screen.Album -> SongListScreen(
                            albumName,
                            listOf(
                                SongSection(
                                    null,
                                    songs.filter { (it.album ?: "No album name") == albumName }.map { SongItem(it, null) },
                                    "No songs in this album.",
                                ),
                            ),
                            player,
                        ) { screen = Screen.Albums }
                        Screen.Radio -> RadioScreen(player)
                        Screen.Travel -> TravelInfoScreen(city = city, fahrenheit = fahrenheit, onOpenSettings = { returnTo = Screen.Travel; screen = Screen.Settings })
                        Screen.Playlists -> PlaylistsScreen(player, songs) { screen = Screen.Home }
                        Screen.Queue -> QueueScreen(player) { screen = Screen.Home }
                        Screen.History -> HistoryScreen(player) { screen = Screen.Home }
                        Screen.Recent -> {
                            val items = songs
                                .filter { (player.counts[it.id] ?: 0L) > 0L }
                                .sortedByDescending { player.lastPlayed[it.id] ?: 0L }
                                .map {
                                    val n = player.counts[it.id] ?: 0L
                                    SongItem(it, "Played ${if (n == 1L) "1 time" else "$n times"} · last played ${ago(player.lastPlayed[it.id] ?: 0L)}")
                                }
                            SongListScreen("Recently Played", listOf(SongSection(null, items, "Nothing played yet. Tap a song to start.")), player) { screen = Screen.Home }
                        }
                        Screen.Most -> {
                            val items = songs
                                .filter { (player.counts[it.id] ?: 0L) > 0L }
                                .sortedByDescending { player.counts[it.id] ?: 0L }
                                .map { SongItem(it, "${plays(player.counts[it.id] ?: 0L)} · last played ${ago(player.lastPlayed[it.id] ?: 0L)}") }
                            SongListScreen("Most Played", listOf(SongSection(null, items, "Nothing played yet. Tap a song to start.")), player) { screen = Screen.Home }
                        }
                        Screen.Favs -> {
                            val favItems = songs.filter { it.id in player.favorites }.map { SongItem(it, null) }
                            val recItems = recommend(songs, player.favorites, player.counts).map { SongItem(it, "Because you like similar songs") }
                            SongListScreen(
                                "Top Favorites",
                                listOf(
                                    SongSection("Your favorites", favItems, "Tap the heart on songs you love and they show up here."),
                                    SongSection("Recommended for you", recItems, "Add a few favorites to get recommendations."),
                                ),
                                player,
                            ) { screen = Screen.Home }
                        }
                        Screen.Settings -> SettingsScreen(
                            name = name,
                            tagline = tagline,
                            accentIdx = accentIdx,
                            dim = dim,
                            hasBg = bgPic != null,
                            hasProfile = profilePic != null,
                            city = city,
                            fahrenheit = fahrenheit,
                            sdArt = sdArt,
                            keepScreenAwakeInDrive = keepScreenAwakeInDrive,
                            onKeepScreenAwakeInDrive = {
                                keepScreenAwakeInDrive = it
                                prefs.edit().putBoolean("keepScreenAwakeInDrive", it).apply()
                            },
                            onBack = { screen = if (returnTo == Screen.Travel) Screen.Travel else Screen.Home },
                            onRename = { askingName = true },
                            onTagline = {
                                tagline = it.take(40)
                                prefs.edit().putString("tagline", tagline).apply()
                            },
                            onAccent = {
                                accentIdx = it
                                prefs.edit().putInt("accent", it).apply()
                            },
                            onDim = {
                                dim = it
                                prefs.edit().putFloat("dim", it).apply()
                            },
                            onCity = {
                                city = it.trim()
                                prefs.edit().putString("city", city).apply()
                            },
                            onFahrenheit = {
                                fahrenheit = it
                                prefs.edit().putBoolean("fahrenheit", it).apply()
                            },
                            onSdArt = {
                                sdArt = it
                                prefs.edit().putBoolean("sdArt", it).apply()
                            },
                            onPickProfile = { pickProfile.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            onRemoveProfile = {
                                File(ctx.filesDir, "profile.jpg").delete()
                                profilePic = null
                            },
                            onPickBg = { pickBg.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            onRemoveBg = {
                                File(ctx.filesDir, "bg.jpg").delete()
                                bgPic = null
                            },
                        )
                        Screen.NowPlaying -> if (landscape) {
                            NowPlayingDrive(player, name, weather, fahrenheit, sdArt)
                        } else {
                            NowPlayingPortrait(player, name, weather, fahrenheit, sdArt, songs, onBack = {
                                screen = if (returnTo == Screen.NowPlaying) Screen.Home else returnTo
                            }, onNavigate = { destination ->
                                returnTo = Screen.NowPlaying
                                screen = when (destination) {
                                    "radio" -> Screen.Radio
                                    "songs" -> Screen.Songs
                                    "home" -> Screen.Home
                                    "nowplaying" -> Screen.NowPlaying
                                    "albums" -> Screen.Albums
                                    "history" -> Screen.History
                                    "settings" -> Screen.Settings
                                    "playlists" -> Screen.Playlists
                                    "favs" -> Screen.Favs
                                    "recent" -> Screen.Recent
                                    "most" -> Screen.Most
                                    else -> Screen.Home
                                }
                            })
                        }
                    }
                }

                Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
                    Box(Modifier.weight(1f)) {
                        if (name.isBlank() || askingName) {
                            AskName(name) {
                                prefs.edit().putString("name", it).apply()
                                name = it
                                askingName = false
                            }
                        } else if (stage == Stage.Hello) {
                            TypewriterScreen("Hello,\n$name") { stage = Stage.Home }
                        } else if (stage == Stage.Goodbye) {
                            TypewriterScreen(farewell()) { activity.finishAndRemoveTask() }
                        } else if (driving) {
                            Row(Modifier.fillMaxSize()) {
                                DriveRail(screen) { screen = it }
                                Box(Modifier.weight(1f)) { content() }
                            }
                        } else {
                            content()
                        }
                    }
                    if (ready && !driving && screen != Screen.NowPlaying) {
                        MiniPlayer(player) { openPlayer() }
                        val tab = screen == Screen.Home || screen == Screen.Songs || screen == Screen.Albums || screen == Screen.Radio
                        if (tab) BottomNav(screen) { screen = it }
                    }
                }
            }
        }
    }
}

@Composable
fun Backdrop(bg: ImageBitmap?, dim: Float) {
    if (bg != null) {
        Image(bg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
    } else {
        RedTunnel()
    }
}

@Composable
fun SkyBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF46B8FF), Color(0xFF2A8FE0), Color(0xFF55C85A))))
        val bubbles = listOf(
            Triple(0.1f, 0.1f, 60f), Triple(0.85f, 0.2f, 40f), Triple(0.9f, 0.7f, 70f),
            Triple(0.15f, 0.8f, 50f), Triple(0.5f, 0.93f, 30f),
        )
        for ((fx, fy, r) in bubbles) {
            val c = Offset(size.width * fx, size.height * fy)
            val rad = r * density
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = 0.7f), Color.White.copy(alpha = 0.08f)),
                    center = c,
                    radius = rad,
                ),
                radius = rad,
                center = c,
            )
            drawCircle(Color.White.copy(alpha = 0.6f), radius = rad, center = c, style = Stroke(1.5f * density))
        }
    }
}

// ---------- icons and art ----------
@Composable
fun VecIcon(d: String, color: Color, dp: Dp, filled: Boolean = true, strokeW: Float = 2f) {
    val path = remember(d) { PathParser().parsePathString(d).toPath() }
    Canvas(Modifier.size(dp)) {
        val s = this.size.minDimension / 24f
        scale(s, s, pivot = Offset.Zero) {
            drawPath(path, color, style = if (filled) Fill else Stroke(width = strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

@Composable
fun IconTap(d: String, color: Color, onClick: () -> Unit, filled: Boolean = true) {
    Box(Modifier.size(48.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        VecIcon(d, color, 26.dp, filled)
    }
}

@Composable
fun StickFigureArt(modifier: Modifier, accent: Color, ink: Color) {
    Canvas(modifier) {
        val u = size.minDimension / 140f
        val w = 4f * u
        drawCircle(ink, 14f * u, Offset(66f * u, 42f * u), style = Stroke(w))
        drawLine(ink, Offset(66f * u, 56f * u), Offset(66f * u, 94f * u), w, StrokeCap.Round)
        drawLine(ink, Offset(66f * u, 94f * u), Offset(52f * u, 120f * u), w, StrokeCap.Round)
        drawLine(ink, Offset(66f * u, 94f * u), Offset(80f * u, 120f * u), w, StrokeCap.Round)
        drawLine(ink, Offset(66f * u, 66f * u), Offset(46f * u, 82f * u), w, StrokeCap.Round)
        drawLine(ink, Offset(66f * u, 66f * u), Offset(90f * u, 62f * u), w, StrokeCap.Round)
        drawRoundRect(
            accent,
            topLeft = Offset(88f * u, 44f * u),
            size = Size(10f * u, 20f * u),
            cornerRadius = CornerRadius(5f * u, 5f * u),
            style = Stroke(w),
        )
    }
}

@Composable
fun SdCardArt(modifier: Modifier, accent: Color, textSize: TextUnit) {
    Box(modifier.background(Color(0xFF14151A)), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val u = size.minDimension / 140f
            val body = Path().apply {
                moveTo(38f * u, 12f * u)
                lineTo(84f * u, 12f * u)
                lineTo(102f * u, 30f * u)
                lineTo(102f * u, 126f * u)
                lineTo(38f * u, 126f * u)
                close()
            }
            drawPath(body, Color(0xFF22252D))
            drawPath(body, Color(0xFF8A93A8), style = Stroke(3f * u))
            drawRect(accent, Offset(47f * u, 44f * u), Size(46f * u, 46f * u))
            for (i in 0..5) {
                drawRect(Color(0xFFD9B44A), Offset((49f + i * 7f) * u, 106f * u), Size(4.5f * u, 16f * u))
            }
        }
        Text("SD", color = Color.White, fontSize = textSize, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ArtContent(song: Song?, station: Station?, dp: Dp, sdArt: Boolean, accent: Color, ink: Color, stationArt: ImageBitmap? = null) {
    val ctx = LocalContext.current
    val art by produceState<ImageBitmap?>(null, song?.id) {
        value = if (song == null) null else withContext(Dispatchers.IO) { loadAlbumArt(ctx, song.uri) }
    }
    Box(Modifier.size(dp).clip(RoundedCornerShape(14.dp))) {
        if (station != null && stationArt != null) {
            Image(stationArt, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else if (station != null) {
            Column(
                Modifier.fillMaxSize().background(Color(0xFF14151A)),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("FM", color = accent, fontSize = (dp.value * 0.28f).sp, fontWeight = FontWeight.Bold)
                Text("RADIO", color = Muted, fontSize = (dp.value * 0.08f).sp, fontWeight = FontWeight.Bold)
            }
        } else if (song != null && song.external && sdArt) {
            SdCardArt(Modifier.fillMaxSize(), accent, (dp.value * 0.17f).sp)
        } else {
            val a = art
            if (a != null) {
                Image(a, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Box(
                    Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF2C2C36), Color(0xFF15151B)))),
                ) { StickFigureArt(Modifier.fillMaxSize(), accent, ink) }
            }
        }
    }
}

@Composable
fun Reflection(dp: Dp, content: @Composable () -> Unit) {
    Box(Modifier.size(dp, dp * 0.3f).clipToBounds()) {
        Box(
            Modifier
                .wrapContentSize(Alignment.TopStart, unbounded = true)
                .requiredSize(dp)
                .graphicsLayer {
                    scaleY = -1f
                    compositingStrategy = CompositingStrategy.Offscreen
                }
                .drawWithContent {
                    drawContent()
                    drawRect(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)),
                            startY = size.height * 0.7f,
                            endY = size.height,
                        ),
                        blendMode = BlendMode.DstIn,
                    )
                },
        ) { content() }
    }
}

@Composable
fun FormatBadge(song: Song, sdArt: Boolean, modifier: Modifier) {
    if (song.external && sdArt) return
    Box(modifier.clip(RoundedCornerShape(8.dp)).background(SkyBlue).padding(horizontal = 8.dp, vertical = 2.dp)) {
        Text(if (song.external) "SD" else song.format, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun GlossOrb(dp: Dp, green: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    val brush = if (green) {
        Brush.verticalGradient(0f to Color(0xFFEAFFE3), 0.48f to Color(0xFF8BE877), 0.52f to Color(0xFF2FB52A), 1f to Color(0xFF96F283))
    } else {
        Brush.verticalGradient(0f to Color(0xFFF2FBFF), 0.48f to Color(0xFFA8E0FF), 0.52f to Color(0xFF4EB6F2), 1f to Color(0xFF97E4FF))
    }
    Box(
        Modifier.size(dp).clip(CircleShape).background(brush).border(1.dp, Color.White, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun GlossPill(text: String, modifier: Modifier, onClick: () -> Unit) {
    val brush = Brush.verticalGradient(0f to Color(0xFFF2FBFF), 0.48f to Color(0xFFB6E6FF), 0.52f to Color(0xFF5CBCF3), 1f to Color(0xFFA3E7FF))
    val shape = RoundedCornerShape(23.dp)
    Box(
        modifier.height(46.dp).clip(shape).background(brush).border(1.dp, Color.White, shape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Navy, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(22.dp)
    Box(
        Modifier.height(44.dp).clip(shape).background(if (selected) accent else Panel)
            .border(1.dp, if (selected) accent else Edge, shape).clickable(onClick = onClick).padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (selected) Color.Black else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun WeatherChip(w: Weather?, f: Boolean, color: Color) {
    if (w == null) return
    val t = if (f) w.tempC * 9 / 5 + 32 else w.tempC
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        VecIcon(weatherIcon(w.code), color, 22.dp, filled = false, strokeW = 1.8f)
        Text("${t.roundToInt()}°${if (f) "F" else "C"} · ${w.city}", color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun OutputChip(out: Output, fg: Color, bg: Color, edge: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(14.dp)).background(bg).border(1.dp, edge, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        VecIcon(outputIcon(out.kind), fg, 22.dp, filled = false, strokeW = 1.8f)
        Text(out.name, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun InfoLine(icon: String, text: String, color: Color, textColor: Color, big: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        VecIcon(icon, color, if (big) 30.dp else 26.dp, filled = false, strokeW = 1.8f)
        Text(
            text,
            color = textColor,
            fontSize = if (big) 24.sp else 17.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun SeekBar(player: PlayerController, textColor: Color, accent: Color) {
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    LaunchedEffect(player.current?.id) {
        while (true) {
            pos = player.exo.currentPosition
            dur = player.exo.duration.coerceAtLeast(0L)
            delay(500)
        }
    }
    Column {
        Slider(
            value = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
            onValueChange = {
                if (dur > 0) {
                    pos = (it * dur).toLong()
                    player.exo.seekTo(pos)
                }
            },
            colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(pos), color = textColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(fmt(dur), color = textColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SpeedPanel(player: PlayerController, textColor: Color) {
    val presets = listOf("0.50x" to 0.5f, "0.75x" to 0.75f, "0.85x" to 0.85f, "1.00x Normal" to 1f, "1.20x" to 1.2f, "1.50x" to 1.5f, "2.00x" to 2f, "4.00x" to 4f)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Speed ${"%.2f".format(player.speed)}x", color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Slider(
            value = player.speed,
            onValueChange = { player.setSpeedValue((it * 20).roundToInt() / 20f) },
            valueRange = 0.25f..4f,
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            presets.forEach { (label, v) -> Pill(label, abs(player.speed - v) < 0.001f) { player.setSpeedValue(v) } }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (player.pitchLock) "Pitch Lock on (speed changes keep the pitch)" else "Pitch Lock off (slower = lower voice)",
                color = textColor,
                fontSize = 13.sp,
                modifier = Modifier.weight(1f),
            )
            Switch(checked = player.pitchLock, onCheckedChange = { player.setPitchLockValue(it) })
        }
    }
}

@Composable
fun EffectsPanel(player: PlayerController, textColor: Color) {
    val fx = player.audioEffects
    var refresh by remember { mutableIntStateOf(0) }
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Audio effects", color = textColor, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Switch(checked = fx.enabled, onCheckedChange = { fx.setEnabled(it); refresh++ })
        }
        Text("Presets", color = textColor, fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Normal", "Slowed+Reverb", "Nightcore", "Bass Boost").forEach { preset ->
                Pill(preset, false) { player.applyAudioPreset(preset); refresh++ }
            }
        }
        Text(if (fx.bassSupported) "Bass Boost · ${fx.bassStrength}" else "Bass Boost isn't supported by this audio output", color = textColor)
        Slider(value = fx.bassStrength.toFloat(), onValueChange = { fx.setBassStrength(it.toInt()); refresh++ }, valueRange = 0f..1000f, enabled = fx.bassSupported)
        Text("Equalizer", color = textColor, fontWeight = FontWeight.SemiBold)
        val count = fx.bandCount
        if (count == 0) Text("The current audio output doesn't expose an equalizer.", color = textColor)
        else {
            for (i in 0 until count) {
                key(i, refresh) {
                    var level by remember(i, refresh) { mutableFloatStateOf(fx.getBandLevel(i.toShort()).toFloat()) }
                    Column {
                        Text("Band ${i + 1} · ${level.toInt()} mB", color = textColor, fontSize = 12.sp)
                        Slider(value = level, onValueChange = { level = it; fx.setBandLevel(i.toShort(), it.toInt()) }, valueRange = fx.bandRange[0].toFloat()..fx.bandRange[1].toFloat())
                    }
                }
            }
        }
        Text("Reverb", color = textColor, fontWeight = FontWeight.SemiBold)
        val reverbOptions = listOf("None" to android.media.audiofx.PresetReverb.PRESET_NONE, "Small room" to android.media.audiofx.PresetReverb.PRESET_SMALLROOM, "Medium room" to android.media.audiofx.PresetReverb.PRESET_MEDIUMROOM, "Large room" to android.media.audiofx.PresetReverb.PRESET_LARGEROOM, "Medium hall" to android.media.audiofx.PresetReverb.PRESET_MEDIUMHALL, "Large hall" to android.media.audiofx.PresetReverb.PRESET_LARGEHALL, "Plate" to android.media.audiofx.PresetReverb.PRESET_PLATE)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            reverbOptions.forEach { (label, value) -> Pill(label, false) { fx.setReverb(value); refresh++ } }
        }
    }
}

@Composable
fun LyricsPanel(player: PlayerController, song: Song, textColor: Color) {
    val ctx = LocalContext.current
    var text by remember(song.id) { mutableStateOf(player.lyricsFor(song.id)) }
    var editing by remember(song.id) { mutableStateOf(false) }
    var draft by remember(song.id) { mutableStateOf("") }
    var status by remember(song.id) { mutableStateOf("") }
    val importLrc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val imported = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (!imported.isNullOrBlank()) {
                    text = imported
                    draft = imported
                    player.saveLyrics(song.id, imported)
                    editing = false
                }
            } catch (_: Exception) { status = "Couldn't read that lyrics file." }
        }
    }
    LaunchedEffect(song.id) {
        if (text == null && isWifi(ctx) && song.title != null) {
            status = "Looking for lyrics…"
            val found = fetchLyrics(song.title, song.artist ?: "")
            if (found != null) {
                text = found
                player.saveLyrics(song.id, found)
            }
            status = ""
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        val shown = text
        if (editing || shown == null) {
            if (shown == null && !editing) {
                Text("No lyrics found. Please add or paste your own lyrics.", color = textColor, fontSize = 14.sp)
                if (status.isNotBlank()) Text(status, color = textColor, fontSize = 12.sp)
            }
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                label = { Text("Paste lyrics") },
                modifier = Modifier.fillMaxWidth().height(180.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    text = draft.ifBlank { null }
                    player.saveLyrics(song.id, draft)
                    editing = false
                }) { Text("Save lyrics") }
                OutlinedButton(onClick = { importLrc.launch(arrayOf("text/*", "application/octet-stream")) }) { Text("Import .lrc") }
            }
        } else {
            val timed = remember(shown) { LrcParser.parse(shown) }
            if (timed.isNotEmpty()) {
                var position by remember(song.id) { mutableLongStateOf(0L) }
                LaunchedEffect(song.id, player.playing) {
                    while (true) { position = player.exo.currentPosition; delay(120) }
                }
                val active = LrcParser.activeIndex(timed, position)
                val listState = rememberLazyListState()
                LaunchedEffect(active) { if (active >= 0) listState.animateScrollToItem(active) }
                LazyColumn(state = listState, modifier = Modifier.fillMaxWidth().height(220.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(timed) { index, line ->
                        Text(line.text, color = if (index == active) LocalAccent.current else textColor.copy(alpha = 0.55f), fontSize = if (index == active) 18.sp else 15.sp, fontWeight = if (index == active) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.fillMaxWidth().clickable { player.exo.seekTo(line.timeMs) }.padding(vertical = 3.dp))
                    }
                }
            } else {
                Column(Modifier.fillMaxWidth().height(220.dp).verticalScroll(rememberScrollState())) {
                    Text(shown, color = textColor, fontSize = 15.sp, lineHeight = 22.sp)
                }
            }
            Button(onClick = { draft = shown; editing = true }) { Text("Edit lyrics / paste .lrc") }
        }
    }
}

// ---------- screens ----------
@Composable
fun AskName(initial: String, onSave: (String) -> Unit) {
    val accent = LocalAccent.current
    var text by remember { mutableStateOf(initial) }
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center) {
        Text("What should I call you?", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(20) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
        )
        Button(
            onClick = { onSave(text.trim()) },
            enabled = text.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
        ) { Text("Continue", fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun TypewriterScreen(text: String, onDone: () -> Unit) {
    val accent = LocalAccent.current
    var shown by remember(text) { mutableIntStateOf(0) }
    LaunchedEffect(text) {
        for (i in 1..text.length) {
            shown = i
            delay(110)
        }
        delay(900)
        onDone()
    }
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.CenterStart) {
        Text(
            text = text.take(shown).uppercase(),
            color = Color.White,
            fontSize = 48.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 56.sp,
            style = TextStyle(shadow = Shadow(accent, blurRadius = 24f)),
        )
    }
}

@Composable
fun RedTunnel() {
    val accent = LocalAccent.current
    val t by rememberInfiniteTransition(label = "tunnel")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "t")
    Canvas(Modifier.fillMaxSize()) {
        val c = Offset(size.width / 2, size.height / 2)
        val left = Brush.horizontalGradient(listOf(accent.copy(alpha = 0.8f), Color.Transparent), 0f, size.width * 0.45f)
        val right = Brush.horizontalGradient(listOf(Color.Transparent, accent.copy(alpha = 0.8f)), size.width * 0.55f, size.width)
        for (i in 0..20) {
            val y = size.height * i / 20f
            drawLine(left, Offset(0f, y), c, 2f)
            drawLine(right, Offset(size.width, y), c, 2f)
        }
        for (k in 0..3) {
            val s = 1f - ((t + k / 4f) % 1f)
            drawOval(
                color = accent.copy(alpha = s * 0.35f),
                topLeft = Offset(c.x - s * size.width * 0.8f, c.y - s * size.height * 0.5f),
                size = Size(s * size.width * 1.6f, s * size.height),
                style = Stroke(2f),
            )
        }
    }
}

@Composable
fun Avatar(pic: ImageBitmap?, name: String, onClick: () -> Unit) {
    val accent = LocalAccent.current
    Box(
        Modifier.size(60.dp).clip(CircleShape).border(2.dp, accent, CircleShape).background(Panel).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (pic != null) {
            Image(pic, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(name.take(1).uppercase(), color = accent, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Tile(title: String, sub: String, filled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.height(92.dp).clip(shape).background(if (filled) accent else Panel)
            .border(1.dp, if (filled) accent else Edge, shape).clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(title, color = if (filled) Color.Black else Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = if (filled) Color.Black else Muted, fontSize = 12.sp)
    }
}

@Composable
fun HomeScreen(
    name: String,
    tagline: String,
    profilePic: ImageBitmap?,
    songs: List<Song>,
    granted: Boolean,
    onAskPermission: () -> Unit,
    player: PlayerController,
    onOpen: (Screen) -> Unit,
) {
    val accent = LocalAccent.current
    val open = LocalOpenPlayer.current
    val recent = songs
        .filter { (player.counts[it.id] ?: 0L) > 0L }
        .sortedByDescending { player.lastPlayed[it.id] ?: 0L }
        .take(5)
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${greeting()},", color = Muted, fontSize = 16.sp)
                    Text(name, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    if (tagline.isNotBlank()) Text(tagline, color = Muted, fontSize = 13.sp)
                }
                Avatar(profilePic, name) { onOpen(Screen.Settings) }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Tile("Recently Played", "What you played lately", false, Modifier.weight(1f)) { onOpen(Screen.Recent) }
                    Tile("Most Played", "Your repeat songs", false, Modifier.weight(1f)) { onOpen(Screen.Most) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Tile("Shuffle", "Random order", true, Modifier.weight(1f)) {
                        player.shuffleAll(songs)
                        if (songs.isNotEmpty()) open()
                    }
                    Tile("Top Favorites", "${player.favorites.size} favorites", false, Modifier.weight(1f)) { onOpen(Screen.Favs) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Tile("Playlists", "${player.playlists.size} saved lists", false, Modifier.weight(1f)) { onOpen(Screen.Playlists) }
                    Tile("Up Next", "${player.upNext.size} queued", false, Modifier.weight(1f)) { onOpen(Screen.Queue) }
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).clickable { onOpen(Screen.History) }.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                VecIcon(SONGS, accent, 24.dp, filled = false, strokeW = 1.8f)
                Text("Radio & Song History", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel)
                    .border(1.dp, Edge, RoundedCornerShape(16.dp)).clickable { onOpen(Screen.Travel) }.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                VecIcon(RAIN, accent, 26.dp, filled = false, strokeW = 1.8f)
                Column(Modifier.weight(1f)) {
                    Text("Travel & Info Center", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Weather · Radar · Traffic · Fuel · News", color = Muted, fontSize = 12.sp)
                }
                VecIcon(NEXT, accent, 20.dp, filled = false)
            }
        }
        if (!granted) {
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("Allow access to the music on your phone so your songs can show up here.", color = Muted, fontSize = 15.sp)
                    Button(
                        onClick = onAskPermission,
                        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
                    ) { Text("Allow music access", fontWeight = FontWeight.Bold) }
                }
            }
        } else if (recent.isEmpty()) {
            item { Text("Tap a song in the Songs tab to get started. Your recent plays show up here.", color = Muted, fontSize = 15.sp) }
        } else {
            item { Text("Recently Played", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            itemsIndexed(recent) { i, s ->
                SongRow(
                    s = s,
                    note = "${plays(player.counts[s.id] ?: 0L)} · last played ${ago(player.lastPlayed[s.id] ?: 0L)}",
                    isFav = s.id in player.favorites,
                    isCurrent = player.current?.id == s.id,
                    onClick = {
                        player.play(recent, i)
                        open()
                    },
                    onFav = { player.toggleFav(s.id) },
                    onQueue = { player.queueNext(s) },
                )
            }
        }
    }
}

@Composable
fun BackHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconTap(CHEVRON, Color.White, onBack)
        Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SongListScreen(title: String, sections: List<SongSection>, player: PlayerController, onBack: () -> Unit) {
    val open = LocalOpenPlayer.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { BackHeader(title, onBack) }
        sections.forEach { sec ->
            sec.title?.let { t ->
                item { Text(t, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            }
            if (sec.items.isEmpty()) {
                item { Text(sec.empty, color = Muted, fontSize = 15.sp) }
            }
            itemsIndexed(sec.items) { i, entry ->
                SongRow(
                    s = entry.song,
                    note = entry.note,
                    isFav = entry.song.id in player.favorites,
                    isCurrent = player.current?.id == entry.song.id,
                    onClick = {
                        player.play(sec.items.map { x -> x.song }, i)
                        open()
                    },
                    onFav = { player.toggleFav(entry.song.id) },
                    onQueue = { player.queueNext(entry.song) },
                )
            }
        }
    }
}

@Composable
fun SongsScreen(songs: List<Song>, player: PlayerController) {
    val open = LocalOpenPlayer.current
    var q by remember { mutableStateOf("") }
    val shown = if (q.isBlank()) songs else songs.filter { s ->
        listOf(s.title, s.album, s.composer, s.artist).any { f -> f?.contains(q, ignoreCase = true) == true }
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                singleLine = true,
                label = { Text("Search songs, albums, composers") },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item { Text("Songs · ${shown.size}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        itemsIndexed(shown) { i, s ->
            SongRow(
                s = s,
                note = null,
                isFav = s.id in player.favorites,
                isCurrent = player.current?.id == s.id,
                onClick = {
                    player.play(shown, i)
                    open()
                },
                onFav = { player.toggleFav(s.id) },
                onQueue = { player.queueNext(s) },
            )
        }
    }
}

@Composable
fun PlaylistsScreen(player: PlayerController, songs: List<Song>, onBack: () -> Unit) {
    var newName by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var rename by remember { mutableStateOf("") }
    val selected = player.playlists.firstOrNull { it.id == selectedId }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { BackHeader("Playlists", onBack) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("New playlist name") }, modifier = Modifier.weight(1f), singleLine = true)
                Button(onClick = { player.createPlaylist(newName); newName = "" }, enabled = newName.isNotBlank()) { Text("Create") }
            }
        }
        if (player.playlists.isEmpty()) item { Text("Create a playlist, then choose it to add songs.", color = Muted) }
        itemsIndexed(player.playlists) { _, p ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable { selectedId = if (selectedId == p.id) null else p.id }) {
                        Text(p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("${p.songIds.size} songs", color = Muted, fontSize = 12.sp)
                    }
                    TextButton(onClick = { player.playPlaylist(p.id, songs) }) { Text("Play") }
                    TextButton(onClick = { player.playPlaylist(p.id, songs, true) }) { Text("Shuffle") }
                    TextButton(onClick = { player.deletePlaylist(p.id); if (selectedId == p.id) selectedId = null }) { Text("Delete") }
                }
                if (selectedId == p.id) {
                    OutlinedTextField(value = rename, onValueChange = { rename = it }, label = { Text("Rename playlist") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    TextButton(onClick = { player.renamePlaylist(p.id, rename); rename = "" }) { Text("Save name") }
                    Text("Add songs", color = LocalAccent.current, fontWeight = FontWeight.Bold)
                    songs.forEach { song ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(song.title ?: "No song name", color = Color.White, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            TextButton(onClick = { player.addToPlaylist(p.id, song) }, enabled = song.id !in p.songIds) { Text(if (song.id in p.songIds) "Added" else "Add") }
                        }
                    }
                    p.songIds.forEach { songId ->
                        val song = songs.firstOrNull { it.id == songId } ?: return@forEach
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(song.title ?: "No song name", color = Muted, modifier = Modifier.weight(1f))
                            TextButton(onClick = { player.removeFromPlaylist(p.id, songId) }) { Text("Remove") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QueueScreen(player: PlayerController, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BackHeader("Up Next", onBack)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { player.clearUpNext() }, enabled = player.upNext.isNotEmpty()) { Text("Clear") }
            }
        }
        if (player.upNext.isEmpty()) item { Text("Nothing queued. Use the arrow beside a song to add it next.", color = Muted) }
        itemsIndexed(player.upNext) { index, song ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).clickable { player.playQueued(index) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(song.title ?: "No song name", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(song.artist ?: song.composer ?: "Unknown Artist", color = Muted, fontSize = 12.sp)
                }
                TextButton(onClick = { player.removeQueued(index) }) { Text("Remove") }
            }
        }
    }
}

@Composable
fun AlbumsScreen(songs: List<Song>, onOpenAlbum: (String) -> Unit) {
    val groups = songs.groupBy { it.album ?: "No album name" }.toSortedMap(String.CASE_INSENSITIVE_ORDER).entries.toList()
    val accent = LocalAccent.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("Albums · ${groups.size}", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        itemsIndexed(groups) { _, g ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).clickable { onOpenAlbum(g.key) }.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                VecIcon(DISC, accent, 28.dp, filled = false, strokeW = 1.8f)
                Column(Modifier.weight(1f)) {
                    Text(g.key, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (g.value.size == 1) "1 song" else "${g.value.size} songs", color = Muted, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun RadioScreen(player: PlayerController) {
    val accent = LocalAccent.current
    val open = LocalOpenPlayer.current
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Station>>(emptyList()) }
    var popular by remember { mutableStateOf<List<Station>>(emptyList()) }
    var status by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { popular = fetchPopularStations() }
    var searchKey by remember { mutableIntStateOf(0) }
    LaunchedEffect(searchKey) {
        if (searchKey > 0 && query.isNotBlank()) {
            status = "Searching…"
            player.rememberRadioSearch(query.trim())
            results = searchStations(query.trim())
            status = if (results.isEmpty()) "No stations found. Check your internet, or try a station name, city, or state." else ""
        }
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("FM Radio", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    label = { Text("Station, city, or state") },
                    modifier = Modifier.weight(1f),
                )
                Button(
                    onClick = { searchKey++ },
                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
                ) { Text("Search", fontWeight = FontWeight.Bold) }
            }
        }
        if (player.radioSearches.isNotEmpty()) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Recent searches", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { player.clearRadioSearches() }) { Text("Clear") }
                }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    player.radioSearches.forEach { term ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(term, color = Muted, modifier = Modifier.weight(1f).clickable { query = term; searchKey++ }.padding(8.dp))
                            TextButton(onClick = { player.removeRadioSearch(term) }) { Text("Remove") }
                        }
                    }
                }
            }
        }
        if (popular.isNotEmpty()) {
            item { Text("Recommended stations", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            itemsIndexed(popular) { _, station ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).clickable { player.playStation(station); open() }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    VecIcon(RADIO, accent, 24.dp, filled = false)
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Text(station.name, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(station.place.ifBlank { "Popular live station" }, color = Muted, fontSize = 12.sp)
                    }
                    TextButton(onClick = { player.togglePreset(station) }) { Text(if (player.presets.any { it.url == station.url }) "Saved" else "Save") }
                }
            }
        }
        if (player.presets.isNotEmpty()) {
            item { Text("Presets", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    player.presets.forEachIndexed { i, s ->
                        Pill("${i + 1}  ${s.name}", player.station?.url == s.url) {
                            player.playStation(s)
                            open()
                        }
                    }
                }
            }
        }
        if (status.isNotBlank()) item { Text(status, color = Muted, fontSize = 15.sp) }
        itemsIndexed(results) { _, s ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).clickable {
                    player.playStation(s)
                    open()
                }.padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                VecIcon(RADIO, accent, 28.dp, filled = false, strokeW = 1.8f)
                Column(Modifier.weight(1f)) {
                    Text(s.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(s.place.ifBlank { "Live radio" }, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                val saved = player.presets.any { it.url == s.url }
                IconTap(HEART, if (saved) accent else Muted, { player.togglePreset(s) }, filled = saved)
            }
        }
    }
}

@Composable
fun SongRow(s: Song, note: String?, isFav: Boolean, isCurrent: Boolean, onClick: () -> Unit, onFav: () -> Unit, onQueue: () -> Unit = {}) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    val art by produceState<ImageBitmap?>(null, s.id) {
        value = withContext(Dispatchers.IO) { loadAlbumArt(ctx, s.uri) }
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).clickable(onClick = onClick).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF26262C)),
            contentAlignment = Alignment.Center,
        ) {
            val a = art
            if (a != null) {
                Image(a, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                VecIcon(NOTE, accent, 28.dp, filled = false, strokeW = 1.8f)
            }
        }
        Column(Modifier.weight(1f)) {
            Text(
                s.title ?: "No song name",
                color = if (isCurrent) accent else Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(s.album ?: "No album name", color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(note ?: s.artist ?: s.composer ?: "Unknown Artist", color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconTap(NEXT, accent, onQueue, filled = false)
        IconTap(HEART, if (isFav) accent else Muted, onFav, filled = isFav)
    }
}

@Composable
fun MiniPlayer(player: PlayerController, onOpen: () -> Unit) {
    if (!player.hasPlayback) return
    val accent = LocalAccent.current
    val s = player.current
    val st = player.station
    Row(
        Modifier.fillMaxWidth().background(Panel).clickable(onClick = onOpen).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                if (st != null) st.name else s?.title ?: "No song name",
                color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                if (st != null) (player.icyTitle ?: "FM Radio") else s?.album ?: "No album name",
                color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        IconTap(PREV, Color.White, { player.previous() })
        IconTap(if (player.playing) PAUSE else PLAY, accent, { player.toggle() })
        IconTap(NEXT, Color.White, { player.next() })
    }
}

@Composable
fun BottomNav(selected: Screen, onSelect: (Screen) -> Unit) {
    val accent = LocalAccent.current
    val tabs = listOf(
        Triple("Home", HOME, Screen.Home),
        Triple("Songs", SONGS, Screen.Songs),
        Triple("Albums", DISC, Screen.Albums),
        Triple("FM Radio", RADIO, Screen.Radio),
    )
    Row(Modifier.fillMaxWidth().background(Color(0xFF0B0B0E)).padding(vertical = 6.dp)) {
        tabs.forEach { (label, d, target) ->
            val on = selected == target
            Column(
                Modifier.weight(1f).clickable { onSelect(target) }.padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                VecIcon(d, if (on) accent else Muted, 24.dp, filled = false, strokeW = 1.8f)
                Text(label, color = if (on) accent else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun DriveRail(selected: Screen, onSelect: (Screen) -> Unit) {
    val accent = LocalAccent.current
    val items = listOf(
        Triple("Now Playing", NOTE, Screen.NowPlaying),
        Triple("Songs", SONGS, Screen.Songs),
        Triple("FM Radio", RADIO, Screen.Radio),
        Triple("Travel", RAIN, Screen.Travel),
        Triple("Home", HOME, Screen.Home),
    )
    Column(
        Modifier.width(84.dp).fillMaxHeight().padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
    ) {
        items.forEach { (label, d, target) ->
            val on = selected == target
            Column(
                Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(14.dp))
                    .background(if (on) Color(0xFF2A1215) else Panel)
                    .border(2.dp, if (on) accent else Edge, RoundedCornerShape(14.dp))
                    .clickable { onSelect(target) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                VecIcon(d, if (on) accent else Color.White, 24.dp, filled = false, strokeW = 1.8f)
                Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    }
}

@Composable
fun HistoryScreen(player: PlayerController, onBack: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { BackHeader("Radio & Song History", onBack) }
        if (player.history.isEmpty()) {
            item { Text("Nothing logged yet. Songs and radio tracks you play will show up here.", color = Muted, fontSize = 15.sp) }
        }
        itemsIndexed(player.history) { _, h ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(12.dp)) {
                Text(h.text, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${h.source} · ${ago(h.at)}", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

// ---------- now playing ----------
@Composable
fun NowPlayingPortrait(
    player: PlayerController,
    name: String,
    weather: Weather?,
    fahrenheit: Boolean,
    sdArt: Boolean,
    songs: List<Song>,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val voiceScope = rememberCoroutineScope()
    val song = player.current
    val st = player.station
    var panel by remember { mutableIntStateOf(0) }
    var out by remember { mutableStateOf(readOutput(ctx)) }
    var voiceStatus by remember { mutableStateOf("") }
    val voice = remember { ClassicVoiceAssistant(ctx) }
    val handleVoiceResult: (String) -> Unit = { phrase ->
        val command = VoiceCommandParser.parse(phrase)
        when {
            command == "play" -> { player.playByUser(); voiceStatus = "Playing" }
            command == "pause" -> { player.pauseByUser(); voiceStatus = "Paused" }
            command == "stop" -> { player.stop(); voiceStatus = "Stopped" }
            command == "next" -> { player.next(); voiceStatus = "Next track" }
            command == "previous" -> { player.previous(); voiceStatus = "Previous track" }
            command == "shuffle" -> { player.toggleShuffle(); voiceStatus = "Shuffle changed" }
            command == "restart" -> { player.exo.seekTo(0); voiceStatus = "Restarting track" }
            command?.startsWith("preset:") == true -> { player.applyAudioPreset(command.substringAfter(":")); voiceStatus = "Audio preset changed" }
            command?.startsWith("speed:") == true -> { command.substringAfter(":").toFloatOrNull()?.let { player.setSpeedValue(it.coerceIn(0.25f, 4f)) }; voiceStatus = "Playback speed changed" }
            command == "show:lyrics" -> { panel = 2; voiceStatus = "Showing lyrics" }
            command == "show:eq" -> { panel = 3; voiceStatus = "Opening equalizer" }
            command == "hide:lyrics" || command == "hide:eq" -> { panel = 0; voiceStatus = "Closing panel" }
            command?.startsWith("screen:") == true -> { onNavigate(command.substringAfter(":")); voiceStatus = "Opening ${command.substringAfter(":")}" }
            command?.startsWith("findsong:") == true -> {
                val term = command.substringAfter(":")
                val match = songs.firstOrNull { it.title?.contains(term, true) == true }
                if (match != null) { player.play(listOf(match), 0); voiceStatus = "Playing ${match.title}" } else voiceStatus = "Song not found"
            }
            command?.startsWith("findartist:") == true -> {
                val term = command.substringAfter(":")
                val matches = songs.filter { it.artist?.contains(term, true) == true || it.composer?.contains(term, true) == true }
                if (matches.isNotEmpty()) { player.play(matches, 0); voiceStatus = "Playing songs by $term" } else voiceStatus = "Artist not found"
            }
            command?.startsWith("findalbum:") == true -> {
                val term = command.substringAfter(":")
                val matches = songs.filter { it.album?.contains(term, true) == true }
                if (matches.isNotEmpty()) { player.play(matches, 0); voiceStatus = "Playing album $term" } else voiceStatus = "Album not found"
            }
            command?.startsWith("findplaylist:") == true -> {
                val term = command.substringAfter(":")
                val match = player.playlists.firstOrNull { it.name.contains(term, true) }
                if (match != null) { player.playPlaylist(match.id, songs); voiceStatus = "Playing playlist ${match.name}" } else voiceStatus = "Playlist not found"
            }
            command?.startsWith("findradio:") == true -> {
                val term = command.substringAfter(":")
                voiceStatus = "Searching radio stations…"
                voiceScope.launch {
                    val match = searchStations(term).firstOrNull()
                    if (match != null) { player.playStation(match); voiceStatus = "Playing ${match.name}" }
                    else voiceStatus = "No station found"
                }
            }
            else -> voiceStatus = "Command not recognized: $phrase"
        }
    }
    val voicePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) voice.start(onResult = handleVoiceResult, onStatus = { voiceStatus = it })
        else voiceStatus = "Microphone permission is needed for voice commands."
    }
    DisposableEffect(Unit) { onDispose { voice.release() } }
    LaunchedEffect(Unit) {
        while (true) {
            out = readOutput(ctx)
            delay(3000)
        }
    }
    val rl = if (st != null) radioLines(st, player.icyTitle) else null
    val line1 = rl?.first ?: song?.album ?: "No album name"
    val line2 = rl?.second ?: song?.title ?: "No song name"
    val line3 = rl?.third ?: song?.let { it.artist ?: it.composer } ?: "Unknown Artist"
    val glass = Brush.verticalGradient(
        listOf(Color.White.copy(alpha = 0.82f), Color(0xFFD6F2FF).copy(alpha = 0.62f), Color(0xFFA0E0FF).copy(alpha = 0.55f)),
    )
    val shape = RoundedCornerShape(26.dp)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconTap(CHEVRON, Navy, onBack)
            Text(name, color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconTap(MIC_PERSON, Navy, {
                if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    voice.start(onResult = handleVoiceResult, onStatus = { voiceStatus = it })
                } else voicePermission.launch(Manifest.permission.RECORD_AUDIO)
            })
            WeatherChip(weather, fahrenheit, NavyMuted)
        }
        if (voiceStatus.isNotBlank()) Text(voiceStatus, color = NavyMuted, fontSize = 12.sp)
        if (song == null && st == null) {
            Text("Nothing is playing. Pick a song from the Songs tab.", color = Navy, fontSize = 16.sp)
            return@Column
        }
        Column(
            Modifier.fillMaxWidth().clip(shape).background(glass).border(1.dp, Color.White, shape).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(240.dp)) {
                    ArtContent(song, st, 240.dp, sdArt, SkyBlue, Navy, player.radioArt)
                    if (song != null) FormatBadge(song, sdArt, Modifier.align(Alignment.TopEnd).padding(8.dp))
                }
                Spacer(Modifier.height(3.dp))
                Reflection(240.dp) { ArtContent(song, st, 240.dp, sdArt, SkyBlue, Navy, player.radioArt) }
            }
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                InfoLine(if (st != null) RADIO else DISC, line1, SkyBlue, NavyMuted, false)
                InfoLine(NOTE, line2, SkyBlue, Navy, false)
                InfoLine(MIC_PERSON, line3, SkyBlue, NavyMuted, false)
                OutputChip(out, Navy, Color.White.copy(alpha = 0.8f), Color.White)
            }
            if (st == null) SeekBar(player, NavyMuted, SkyBlue)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlossOrb(48.dp, false, { if (st == null) player.toggleShuffle() }) {
                    VecIcon(SHUFFLE, if (st != null) Navy.copy(alpha = 0.3f) else if (player.shuffleOn) SkyBlue else Navy, 22.dp, filled = false)
                }
                GlossOrb(48.dp, false, { player.previous() }) { VecIcon(PREV, Navy, 22.dp) }
                GlossOrb(68.dp, true, { player.toggle() }) {
                    VecIcon(if (player.playing) PAUSE else PLAY, Color(0xFF0B3D12), 28.dp)
                }
                GlossOrb(48.dp, false, { player.next() }) { VecIcon(NEXT, Navy, 22.dp) }
                GlossOrb(48.dp, false, { player.stop() }) { VecIcon(STOP, Navy, 20.dp) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlossPill("Speed & Pitch · ${"%.2f".format(player.speed)}x", Modifier.weight(1f)) { panel = if (panel == 1) 0 else 1 }
                if (song != null) GlossPill("Lyrics", Modifier.weight(1f)) { panel = if (panel == 2) 0 else 2 }
                GlossPill("EQ & Effects", Modifier.weight(1f)) { panel = if (panel == 3) 0 else 3 }
            }
            if (panel == 1) SpeedPanel(player, Navy)
            if (panel == 2 && song != null) LyricsPanel(player, song, Navy)
            if (panel == 3) EffectsPanel(player, Navy)
        }
    }
}

@Composable
fun NowPlayingDrive(player: PlayerController, name: String, weather: Weather?, fahrenheit: Boolean, sdArt: Boolean) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    val song = player.current
    val st = player.station
    var out by remember { mutableStateOf(readOutput(ctx)) }
    var clock by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            out = readOutput(ctx)
            clock = LocalTime.now()
            delay(3000)
        }
    }
    val rl = if (st != null) radioLines(st, player.icyTitle) else null
    val line1 = rl?.first ?: song?.album ?: "No album name"
    val line2 = rl?.second ?: song?.title ?: "No song name"
    val line3 = rl?.third ?: song?.let { it.artist ?: it.composer } ?: "Unknown Artist"
    var lyricPosition by remember(song?.id) { mutableLongStateOf(0L) }
    LaunchedEffect(song?.id, player.playing) {
        while (song != null) { lyricPosition = player.exo.currentPosition; delay(250) }
    }
    val driveLyrics = remember(song?.id) { song?.let { player.lyricsFor(it.id)?.let { raw -> LrcParser.parse(raw) } } ?: emptyList() }
    val activeDriveLyric = LrcParser.activeIndex(driveLyrics, lyricPosition).takeIf { it >= 0 }?.let { driveLyrics[it].text }
    if (song == null && st == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Nothing is playing. Pick something from Songs or FM Radio.", color = Color.White, fontSize = 20.sp)
        }
        return
    }
    BoxWithConstraints(Modifier.fillMaxSize().padding(12.dp)) {
        val artSize = maxHeight * 0.68f
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            Column {
                Box(Modifier.size(artSize)) {
                    ArtContent(song, st, artSize, sdArt, accent, Color(0xFFF2F2F4), player.radioArt)
                    if (song != null) FormatBadge(song, sdArt, Modifier.align(Alignment.TopEnd).padding(8.dp))
                }
                Spacer(Modifier.height(3.dp))
                Reflection(artSize) { ArtContent(song, st, artSize, sdArt, accent, Color(0xFFF2F2F4), player.radioArt) }
            }
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(clock.format(DateTimeFormatter.ofPattern("h:mm a")), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    WeatherChip(weather, fahrenheit, Color.White)
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoLine(if (st != null) RADIO else DISC, line1, accent, Muted, true)
                    InfoLine(NOTE, line2, accent, Color.White, true)
                    InfoLine(MIC_PERSON, line3, accent, Muted, true)
                    if (activeDriveLyric != null) Text(activeDriveLyric, color = accent, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutputChip(out, Color.White, Color(0xFF1A0C0E), Color(0xFF5A1A1D))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("Speed ${"%.2f".format(player.speed)}x", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Slider(value = player.speed, onValueChange = { player.setSpeedValue(it) }, valueRange = 0.25f..4f, modifier = Modifier.fillMaxWidth().height(24.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Pitch lock", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                                Switch(checked = player.pitchLock, onCheckedChange = { player.setPitchLockValue(it) })
                            }
                        }
                    }
                }
                if (st == null) SeekBar(player, Muted, accent)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    DriveOrb(56.dp, false, { if (st == null) player.toggleShuffle() }) { VecIcon(SHUFFLE, if (st != null) Color(0xFF555560) else if (player.shuffleOn) accent else Color.White, 24.dp, filled = false) }
                    DriveOrb(56.dp, false, { player.previous() }) { VecIcon(PREV, Color.White, 24.dp) }
                    DriveOrb(76.dp, true, { player.toggle() }) { VecIcon(if (player.playing) PAUSE else PLAY, Color.White, 32.dp) }
                    DriveOrb(56.dp, false, { player.next() }) { VecIcon(NEXT, Color.White, 24.dp) }
                    DriveOrb(56.dp, false, { player.stop() }) { VecIcon(STOP, Color.White, 22.dp) }
                }
            }
        }
    }
}

@Composable
fun DriveOrb(dp: Dp, primary: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    val accent = LocalAccent.current
    Box(
        Modifier.size(dp).clip(CircleShape).background(if (primary) accent else Panel)
            .border(2.dp, if (primary) accent else Edge, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}


// ---------- Travel & Info Center ----------
private enum class TravelTab(val label: String) { Weather("Weather"), Radar("Radar"), Traffic("Traffic"), Fuel("Fuel"), Sports("Sports"), News("News") }

@Composable
fun TravelInfoScreen(city: String, fahrenheit: Boolean, onOpenSettings: () -> Unit) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    var tab by remember { mutableStateOf(TravelTab.Weather) }
    var snapshot by remember(city) { mutableStateOf(TravelSnapshotCache.get(city)) }
    var loading by remember(city) { mutableStateOf(false) }
    var refreshKey by remember(city) { mutableIntStateOf(0) }
    var loadError by remember(city) { mutableStateOf("") }

    fun openExternal(url: String) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { }
    }

    LaunchedEffect(city, refreshKey) {
        if (city.isNotBlank()) {
            val cached = if (refreshKey == 0) TravelSnapshotCache.get(city) else null
            if (cached != null) {
                snapshot = cached
                loadError = ""
            } else {
                loading = true
                val result = fetchTravelSnapshot(city)
                snapshot = result
                if (result != null) TravelSnapshotCache.put(city, result)
                loadError = if (result == null) "Weather information could not be loaded. Check the city in Settings and try again." else ""
                loading = false
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("TRAVEL & INFO CENTER", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Your road information", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text(if (city.isBlank()) "Set a city in Settings to load local information" else "${snapshot?.city ?: city} · Live information when available", color = Muted, fontSize = 13.sp)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TravelTab.values().forEach { item -> Pill(item.label, tab == item) { tab = item } }
            }
        }
        when (tab) {
            TravelTab.Weather -> {
                if (city.isBlank()) {
                    item { TravelNotice("Location not set", "Choose a city in Chrome Deck Settings to load weather, forecast and local alerts.") }
                    item { Button(onClick = onOpenSettings, colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)) { Text("Open Settings") } }
                } else {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("CURRENT CONDITIONS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { if (!loading) refreshKey++ }) { Text(if (loading) "Updating…" else "Refresh", color = accent) }
                        }
                    }
                    if (snapshot != null) {
                        val data = snapshot!!
                        item {
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).border(1.dp, Edge, RoundedCornerShape(18.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                VecIcon(weatherIcon(data.current.code), accent, 54.dp, filled = false, strokeW = 1.7f)
                                Spacer(Modifier.width(16.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("${if (fahrenheit) (data.current.tempC * 9 / 5 + 32).roundToInt() else data.current.tempC.roundToInt()}°${if (fahrenheit) "F" else "C"}", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                                    Text(weatherDescription(data.current.code), color = Muted, fontSize = 14.sp)
                                    Text(data.city, color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        item { Text("5-DAY OUTLOOK", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp) }
                        items(data.forecast) { day ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(day.date.takeLast(5), color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                VecIcon(weatherIcon(day.code), accent, 22.dp, filled = false)
                                Text("${if (fahrenheit) (day.highC * 9 / 5 + 32).roundToInt() else day.highC.roundToInt()}° / ${if (fahrenheit) (day.lowC * 9 / 5 + 32).roundToInt() else day.lowC.roundToInt()}°", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp))
                                Text("${day.precipitationChance}%", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 10.dp))
                            }
                        }
                        item {
                            Text("ACTIVE WEATHER ALERTS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            if (data.alerts == null) {
                                TravelNotice("Alerts unavailable", "The National Weather Service alert service did not return data. Check weather.gov for current official alerts.")
                            } else if (data.alerts.isEmpty()) {
                                TravelNotice("No active NWS alerts returned", "The National Weather Service currently returned no active alerts for this point. Always follow local official guidance.")
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    data.alerts.forEach { alert ->
                                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF241719)).border(1.dp, Color(0xFF653036), RoundedCornerShape(12.dp)).padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                            Text(alert.event.uppercase(), color = Color(0xFFFF7777), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text(alert.headline, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                            Text("Severity: ${alert.severity}", color = Muted, fontSize = 12.sp)
                                            if (alert.description.isNotBlank()) Text(alert.description, color = Muted, fontSize = 12.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                        item { Text("Weather data by Open-Meteo · Alerts by the U.S. National Weather Service", color = Muted, fontSize = 10.sp) }
                    } else if (loading) {
                        item { TravelNotice("Loading local weather…", "Fetching current conditions, a five-day outlook and active official alerts.") }
                    } else {
                        item { TravelNotice("Weather unavailable", loadError.ifBlank { "Check your city setting and internet connection." }) }
                    }
                }
            }
            TravelTab.Radar -> {
                item {
                    TravelNotice("Weather radar", "Radar imagery is provided by RainViewer. The free public API currently offers recent historical radar frames; future nowcast frames are no longer part of the free API.")
                }
                item {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).border(1.dp, Edge, RoundedCornerShape(16.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("LIVE RADAR MAP", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(if (city.isBlank()) "Set a city in Settings before opening a local radar view." else "Open RainViewer to view its interactive radar map. Select your area on the map.", color = Muted, fontSize = 13.sp)
                        Button(onClick = { openExternal("https://www.rainviewer.com/") }, enabled = city.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)) { Text("Open RainViewer") }
                        Text("Source: RainViewer · Recent radar frames · Attribution required", color = Muted, fontSize = 10.sp)
                    }
                }
            }
            TravelTab.Traffic -> {
                item {
                    TravelNotice(
                        "Florida traffic · FL511",
                        "Florida's Department of Transportation is Chrome Deck's preferred traffic source. FL511 provides current incidents, congestion, construction, closures, travel times, road cameras and weather-related travel alerts."
                    )
                }
                item {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(Panel).border(1.dp, Edge, RoundedCornerShape(16.dp)).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("FLORIDA 511", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("Official Florida traffic information", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Open the official statewide traffic map for Florida${if (city.isNotBlank()) " · selected area: $city" else ""}. Choose traffic speeds, incidents, closures, construction and camera layers on the FL511 map.", color = Muted, fontSize = 13.sp)
                        Button(
                            onClick = { openExternal("https://www.fl511.com/") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)
                        ) { Text("OPEN OFFICIAL FL511 MAP", fontWeight = FontWeight.Bold) }
                        Text("Florida Department of Transportation · Free public traveler information", color = Muted, fontSize = 10.sp)
                    }
                }
                item {
                    TravelAction("FL511 MAP LAYERS", "Traffic speeds · Incidents · Cameras · Closures · Construction", accent) {
                        openExternal("https://www.fl511.com/Map/EmbeddedMapSetup")
                    }
                }
                item {
                    TravelNotice("Native integration status", "FL511's official site documents an embeddable interactive map for websites. A supported public native-app data API has not yet been confirmed, so Chrome Deck opens the official Florida service rather than scraping it or displaying unverified traffic data.")
                }
            }
            TravelTab.Fuel -> {
                item { TravelNotice("Nearby fuel stations", "Browse nearby stations on a map. Chrome Deck will only show prices inside the app after a reliable licensed price source is selected; it will not invent or estimate prices.") }
                item { TravelAction("FIND FUEL STATIONS", "Search around $city", accent) { openExternal("https://www.google.com/maps/search/?api=1&query=${enc("gas stations near $city")}") } }
            }
            TravelTab.Sports -> {
                item { TravelNotice("Sports information", "The native sports scoreboard is being prepared. A licensed or officially documented data provider must be selected before Chrome Deck displays scores or headlines.") }
            }
            TravelTab.News -> {
                item { TravelNotice("News center", "The news reader is being prepared for official publisher feeds. Headlines will include their source and publication time; no placeholder headlines will be presented as live news.") }
            }
        }
        item { Spacer(Modifier.height(10.dp)) }
    }
}

@Composable
private fun TravelNotice(title: String, message: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).border(1.dp, Edge, RoundedCornerShape(14.dp)).padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(message, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
    }
}

@Composable
private fun TravelAction(title: String, detail: String, accent: Color, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).border(1.dp, Edge, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Text(detail, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

private fun weatherDescription(code: Int): String = when (code) {
    0 -> "Clear sky"
    1 -> "Mainly clear"
    2 -> "Partly cloudy"
    3 -> "Overcast"
    45, 48 -> "Fog"
    in 51..57 -> "Drizzle"
    in 61..67 -> "Rain"
    in 71..77 -> "Snow"
    in 80..82 -> "Rain showers"
    in 85..86 -> "Snow showers"
    95, 96, 99 -> "Thunderstorm"
    else -> "Variable conditions"
}

// ---------- settings ----------
@Composable
fun SettingsScreen(
    name: String,
    tagline: String,
    accentIdx: Int,
    dim: Float,
    hasBg: Boolean,
    hasProfile: Boolean,
    city: String,
    fahrenheit: Boolean,
    sdArt: Boolean,
    keepScreenAwakeInDrive: Boolean,
    onKeepScreenAwakeInDrive: (Boolean) -> Unit,
    onBack: () -> Unit,
    onRename: () -> Unit,
    onTagline: (String) -> Unit,
    onAccent: (Int) -> Unit,
    onDim: (Float) -> Unit,
    onCity: (String) -> Unit,
    onFahrenheit: (Boolean) -> Unit,
    onSdArt: (Boolean) -> Unit,
    onPickProfile: () -> Unit,
    onRemoveProfile: () -> Unit,
    onPickBg: () -> Unit,
    onRemoveBg: () -> Unit,
) {
    val accent = LocalAccent.current
    val btn = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)
    val quiet = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Color.White)
    var cityDraft by remember { mutableStateOf(city) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        BackHeader("Settings", onBack)
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Keep screen awake in Drive Mode", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("Prevents the display from sleeping while Drive Mode is active", color = Muted, fontSize = 12.sp)
            }
            Switch(checked = keepScreenAwakeInDrive, onCheckedChange = onKeepScreenAwakeInDrive)
        }
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).clickable(onClick = onRename).padding(16.dp),
        ) {
            Text("Name", color = Muted, fontSize = 13.sp)
            Text(name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(
            value = tagline,
            onValueChange = onTagline,
            singleLine = true,
            label = { Text("Tagline") },
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Profile picture", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onPickProfile, colors = btn) { Text("Choose photo", fontWeight = FontWeight.Bold) }
            if (hasProfile) Button(onClick = onRemoveProfile, colors = quiet) { Text("Remove") }
        }
        Text("Home background", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onPickBg, colors = btn) { Text("Choose photo", fontWeight = FontWeight.Bold) }
            if (hasBg) Button(onClick = onRemoveBg, colors = quiet) { Text("Use default") }
        }
        if (hasBg) {
            Text("Photo darkness", color = Muted, fontSize = 13.sp)
            Slider(value = dim, onValueChange = onDim, valueRange = 0f..0.9f)
        }
        Text("Accent color", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Accents.forEachIndexed { i, c ->
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(c)
                        .border(if (i == accentIdx) 3.dp else 0.dp, Color.White, CircleShape)
                        .clickable { onAccent(i) },
                )
            }
        }
        Text("Weather", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = cityDraft,
                onValueChange = { cityDraft = it },
                singleLine = true,
                label = { Text("City") },
                modifier = Modifier.weight(1f),
            )
            Button(onClick = { onCity(cityDraft) }, colors = btn) { Text("Save", fontWeight = FontWeight.Bold) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Show °F (turn off for °C)", color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Switch(checked = fahrenheit, onCheckedChange = onFahrenheit)
        }
        Text("Album art", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Show an SD card picture for songs on the SD card", color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Switch(checked = sdArt, onCheckedChange = onSdArt)
        }
        Text("Chrome Deck version $APP_VERSION", color = Muted, fontSize = 13.sp)
    }
}
