package com.example.retroplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalTime

private val Red = Color(0xFFFF2D2D)
private val Muted = Color(0xFFC4C4CC)
private val Panel = Color(0xFF1A0C0E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

// ---------- greetings ----------
fun greeting(): String = when (LocalTime.now().hour) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..20 -> "Good evening"
    else -> "Good night"
}

fun farewell(): String {
    val h = LocalTime.now().hour
    return if (h >= 21 || h < 5) "Good night" else "Goodbye"
}

// ---------- music library ----------
data class Song(val id: Long, val title: String?, val album: String?, val composer: String?, val uri: Uri)

fun String?.clean(): String? = this?.takeIf { it.isNotBlank() && it != "<unknown>" }

fun scanSongs(ctx: Context): List<Song> {
    val list = mutableListOf<Song>()
    val base = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ALBUM,
    )
    val hasComposer = Build.VERSION.SDK_INT >= 30
    val projection = if (hasComposer) base + MediaStore.Audio.Media.COMPOSER else base
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        projection,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0",
        null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC",
    )?.use { c ->
        val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val iComp = if (hasComposer) c.getColumnIndex(MediaStore.Audio.Media.COMPOSER) else -1
        while (c.moveToNext()) {
            val id = c.getLong(iId)
            list.add(
                Song(
                    id = id,
                    title = c.getString(iTitle).clean(),
                    album = c.getString(iAlbum).clean(),
                    composer = if (iComp >= 0) c.getString(iComp).clean() else null,
                    uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                ),
            )
        }
    }
    return list
}

fun loadAlbumArt(ctx: Context, uri: Uri): ImageBitmap? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        val bytes = r.embeddedPicture
        if (bytes == null) {
            null
        } else {
            val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)?.asImageBitmap()
        }
    } catch (e: Exception) {
        null
    } finally {
        r.release()
    }
}

// ---------- screens ----------
enum class Stage { Hello, Home, Goodbye }

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("retro", Context.MODE_PRIVATE) }
    var name by remember { mutableStateOf(prefs.getString("name", "") ?: "") }
    var editing by remember { mutableStateOf(false) }
    var stage by remember { mutableStateOf(Stage.Hello) }
    val activity = ctx as Activity
    BackHandler(enabled = stage == Stage.Home && !editing) { stage = Stage.Goodbye }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            RedTunnel()
            Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
                if (name.isBlank() || editing) {
                    AskName(name) {
                        prefs.edit().putString("name", it).apply()
                        name = it
                        editing = false
                    }
                } else {
                    when (stage) {
                        Stage.Hello -> TypewriterScreen("Hello,\n$name") { stage = Stage.Home }
                        Stage.Home -> HomeScreen(name) { editing = true }
                        Stage.Goodbye -> TypewriterScreen(farewell()) { activity.finishAndRemoveTask() }
                    }
                }
            }
        }
    }
}

@Composable
fun AskName(initial: String, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center) {
        Text("What should I call you?", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(20) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
        )
        Button(
            onClick = { onSave(text.trim()) },
            enabled = text.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White),
        ) { Text("Continue", fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun TypewriterScreen(text: String, onDone: () -> Unit) {
    var shown by remember(text) { mutableIntStateOf(0) }
    LaunchedEffect(text) {
        for (i in 1..text.length) {
            shown = i
            delay(110)
        }
        delay(900)
        onDone()
    }
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.CenterStart) {
        Text(
            text = text.take(shown).uppercase(),
            color = Color.White,
            fontSize = 48.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 56.sp,
            style = TextStyle(shadow = Shadow(Red, blurRadius = 24f)),
        )
    }
}

@Composable
fun RedTunnel() {
    val t by rememberInfiniteTransition(label = "tunnel")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "t")
    Canvas(Modifier.fillMaxSize()) {
        val c = Offset(size.width / 2, size.height / 2)
        val left = Brush.horizontalGradient(listOf(Red.copy(alpha = 0.8f), Color.Transparent), 0f, size.width * 0.45f)
        val right = Brush.horizontalGradient(listOf(Color.Transparent, Red.copy(alpha = 0.8f)), size.width * 0.55f, size.width)
        for (i in 0..20) {
            val y = size.height * i / 20f
            drawLine(left, Offset(0f, y), c, 2f)
            drawLine(right, Offset(size.width, y), c, 2f)
        }
        for (k in 0..3) {
            val s = 1f - ((t + k / 4f) % 1f)
            drawOval(
                color = Red.copy(alpha = s * 0.35f),
                topLeft = Offset(c.x - s * size.width * 0.8f, c.y - s * size.height * 0.5f),
                size = Size(s * size.width * 1.6f, s * size.height),
                style = Stroke(2f),
            )
        }
    }
}

@Composable
fun HomeScreen(name: String, onRename: () -> Unit) {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    LaunchedEffect(granted) {
        if (granted) songs = withContext(Dispatchers.IO) { scanSongs(ctx) }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth().clickable { onRename() }, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${greeting()},", color = Muted, fontSize = 16.sp)
                    Text(name, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(60.dp).clip(CircleShape).border(2.dp, Red, CircleShape).background(Panel))
            }
        }
        if (!granted) {
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("Allow access to the music on your phone so your songs can show up here.", color = Muted, fontSize = 15.sp)
                    Button(
                        onClick = { ask.launch(perm) },
                        colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White),
                    ) { Text("Allow music access", fontWeight = FontWeight.Bold) }
                }
            }
        } else {
            item { Text("Songs · ${songs.size}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            if (songs.isEmpty()) {
                item { Text("No songs found yet.", color = Muted, fontSize = 15.sp) }
            }
            items(songs, key = { it.id }) { SongRow(it) }
        }
    }
}

@Composable
fun SongRow(s: Song) {
    val ctx = LocalContext.current
    val art by produceState<ImageBitmap?>(null, s.id) {
        value = withContext(Dispatchers.IO) { loadAlbumArt(ctx, s.uri) }
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2C1417)),
            contentAlignment = Alignment.Center,
        ) {
            val a = art
            if (a != null) {
                Image(a, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Text("♪", color = Red, fontSize = 26.sp)
            }
        }
        Column(Modifier.weight(1f)) {
            Text(s.title ?: "No song name", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(s.album ?: "No album name", color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(s.composer ?: "No composer", color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
