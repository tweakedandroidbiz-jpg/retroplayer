package com.example.retroplayer

import android.app.PendingIntent
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

/** Android Auto / media-browser entry point backed by the app's existing ExoPlayer. */
@OptIn(UnstableApi::class)
class ChromeDeckAutoService : MediaLibraryService() {
    private var librarySession: MediaLibrarySession? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        val player = (application as RetroApp).player
        val callback = ChromeDeckLibraryCallback(player)
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val sessionActivity = launchIntent?.let {
            PendingIntent.getActivity(
                this,
                7001,
                it.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
        }
        val builder = MediaLibrarySession.Builder(this, player.exo, callback)
        if (sessionActivity != null) builder.setSessionActivity(sessionActivity)
        librarySession = builder.build()

        val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
            else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(audioPermission) == PackageManager.PERMISSION_GRANTED) {
            serviceScope.launch {
                val songs = try { scanSongs(this@ChromeDeckAutoService) } catch (_: Exception) { emptyList() }
                player.librarySongs = songs
                withContext(Dispatchers.Main) {
                    librarySession?.notifyChildrenChanged("songs", songs.size, null)
                }
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = librarySession

    override fun onDestroy() {
        librarySession?.release()
        librarySession = null
        serviceScope.cancel()
        super.onDestroy()
    }
}

@OptIn(UnstableApi::class)
private class ChromeDeckLibraryCallback(
    private val player: PlayerController,
) : MediaLibraryService.MediaLibrarySession.Callback {

    override fun onGetLibraryRoot(
        session: MediaLibraryService.MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        params: MediaLibraryService.LibraryParams?,
    ): ListenableFuture<LibraryResult<MediaItem>> {
        val root = folder("root", "Chrome Deck")
        return Futures.immediateFuture(LibraryResult.ofItem(root, params))
    }

    override fun onGetChildren(
        session: MediaLibraryService.MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        parentId: String,
        page: Int,
        pageSize: Int,
        params: MediaLibraryService.LibraryParams?,
    ): ListenableFuture<LibraryResult<com.google.common.collect.ImmutableList<MediaItem>>> {
        val children = childrenFor(parentId)
        val start = (page.coerceAtLeast(0) * pageSize.coerceAtLeast(1)).coerceAtMost(children.size)
        val pageItems = children.drop(start).take(pageSize.coerceAtLeast(1))
        return Futures.immediateFuture(LibraryResult.ofItemList(pageItems, params))
    }

    override fun onGetItem(
        session: MediaLibraryService.MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        mediaId: String,
    ): ListenableFuture<LibraryResult<MediaItem>> {
        val item = itemForId(mediaId)
        return if (item != null) Futures.immediateFuture(LibraryResult.ofItem(item, null))
        else Futures.immediateFuture(LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE, null))
    }

    override fun onSetMediaItems(
        mediaSession: MediaSession,
        controller: MediaSession.ControllerInfo,
        mediaItems: MutableList<MediaItem>,
        startIndex: Int,
        startPositionMs: Long,
    ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
        val selectedIndex = if (startIndex in mediaItems.indices) startIndex else 0
        val selected = mediaItems.getOrNull(selectedIndex)
        val selectedId = selected?.mediaId.orEmpty()

        if (selectedId.startsWith("radio|")) {
            val resolved = mediaItems.map { item ->
                val id = item.mediaId
                if (id.startsWith("radio|")) {
                    val url = id.removePrefix("radio|")
                    val station = player.presets.firstOrNull { it.url == url }
                    stationItem(station ?: Station(item.mediaMetadata.title?.toString() ?: "Radio station", url, ""))
                } else item
            }
            return Futures.immediateFuture(
                MediaSession.MediaItemsWithStartPosition(resolved, selectedIndex.coerceIn(resolved.indices), startPositionMs),
            )
        }

        val playlistId = selectedId.takeIf { it.startsWith("playlistSong|") }
            ?.split('|')?.getOrNull(1)
        val songId = selectedId.substringAfterLast('|').toLongOrNull()
        val sourceSongs = if (playlistId != null) {
            val ids = player.playlists.firstOrNull { it.id == playlistId }?.songIds.orEmpty()
            ids.mapNotNull { id -> player.librarySongs.firstOrNull { it.id == id } }
        } else if (songId != null) {
            player.librarySongs
        } else emptyList()

        if (sourceSongs.isNotEmpty() && songId != null) {
            val mapped = sourceSongs.map { localItem(it) }
            val index = mapped.indexOfFirst { it.mediaId == songId.toString() }.coerceAtLeast(0)
            return Futures.immediateFuture(
                MediaSession.MediaItemsWithStartPosition(mapped, index, startPositionMs),
            )
        }

        return Futures.immediateFuture(
            MediaSession.MediaItemsWithStartPosition(mediaItems, selectedIndex, startPositionMs),
        )
    }

    private fun childrenFor(parentId: String): List<MediaItem> = when {
        parentId == "root" -> listOf(
            folder("stations", "Saved Radio Stations"),
            folder("playlists", "Playlists"),
            folder("songs", "Local Songs"),
        )
        parentId == "stations" -> player.presets.map(::stationItem)
        parentId == "playlists" -> player.playlists.map { playlist ->
            folder("playlist:${playlist.id}", playlist.name)
        }
        parentId == "songs" -> player.librarySongs.map(::songBrowseItem)
        parentId.startsWith("playlist:") -> {
            val id = parentId.removePrefix("playlist:")
            val playlist = player.playlists.firstOrNull { it.id == id }
            playlist?.songIds.orEmpty().mapNotNull { songId ->
                player.librarySongs.firstOrNull { it.id == songId }?.let { song -> playlistSongItem(playlist!!.id, song) }
            }
        }
        else -> emptyList()
    }

    private fun itemForId(id: String): MediaItem? = when {
        id == "root" -> folder("root", "Chrome Deck")
        id == "stations" || id == "playlists" || id == "songs" -> folder(id, id.replaceFirstChar { it.uppercase() })
        id.startsWith("playlist:") -> player.playlists.firstOrNull { "playlist:${it.id}" == id }
            ?.let { folder(id, it.name) }
        id.startsWith("radio|") -> {
            val url = id.removePrefix("radio|")
            val station = player.presets.firstOrNull { it.url == url } ?: Station("Radio station", url, "")
            stationItem(station)
        }
        id.startsWith("playlistSong|") -> {
            val parts = id.split('|')
            val songId = parts.lastOrNull()?.toLongOrNull()
            val song = player.librarySongs.firstOrNull { it.id == songId }
            val playlistId = parts.getOrNull(1)
            if (song != null && playlistId != null) playlistSongItem(playlistId, song) else null
        }
        id.startsWith("song|") -> {
            val songId = id.substringAfter('|').toLongOrNull()
            player.librarySongs.firstOrNull { it.id == songId }?.let(::songBrowseItem)
        }
        else -> null
    }

    private fun folder(id: String, title: String): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                .build(),
        )
        .build()

    private fun stationItem(station: Station): MediaItem {
        val artwork = station.logoUrl.takeIf { it.isNotBlank() }?.let(Uri::parse)
            ?: try { Uri.parse("https://www.google.com/s2/favicons?domain_url=${Uri.encode("https://${URL(station.url).host}")}&sz=256") } catch (_: Exception) { null }
        return MediaItem.Builder()
        .setMediaId("radio|${station.url}")
        .setUri(Uri.parse(station.url))
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(station.name)
                .setArtist("Internet Radio")
                .setArtworkUri(artwork)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_RADIO_STATION)
                .build(),
        )
        .build()
    }

    private fun songBrowseItem(song: Song): MediaItem = MediaItem.Builder()
        .setMediaId("song|${song.id}")
        .setUri(song.uri)
        .setMediaMetadata(songMetadata(song))
        .build()

    private fun playlistSongItem(playlistId: String, song: Song): MediaItem = MediaItem.Builder()
        .setMediaId("playlistSong|$playlistId|${song.id}")
        .setUri(song.uri)
        .setMediaMetadata(songMetadata(song))
        .build()

    private fun localItem(song: Song): MediaItem = MediaItem.Builder()
        .setMediaId(song.id.toString())
        .setUri(song.uri)
        .setMediaMetadata(songMetadata(song))
        .build()

    private fun songMetadata(song: Song): MediaMetadata = MediaMetadata.Builder()
        .setTitle(song.title ?: "Unknown track")
        .setArtist(song.artist ?: song.composer ?: "Unknown artist")
        .setAlbumTitle(song.album ?: "")
        .setArtworkUri(song.albumId?.let { Uri.parse("content://media/external/audio/albumart/$it") })
        .setIsBrowsable(false)
        .setIsPlayable(true)
        .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
        .build()
}
