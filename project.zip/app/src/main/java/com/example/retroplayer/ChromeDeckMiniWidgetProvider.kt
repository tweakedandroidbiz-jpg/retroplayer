package com.example.retroplayer

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

/** Compact 2x1 companion widget. */
class ChromeDeckMiniWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { ChromeDeckWidgetProvider.updateForLayout(context, manager, it, R.layout.chrome_deck_widget_mini) }
    }
}
