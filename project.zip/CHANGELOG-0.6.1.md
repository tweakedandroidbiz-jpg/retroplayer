# Chrome Deck 0.6.1

## Android media controls and widgets
- Improved Media3 media-session synchronization for playback state and live stream metadata.
- Request the media playback service before starting local or internet-radio playback.
- Added artwork-aware compact and standard home-screen widgets.
- Added an expanded home-screen player widget with artwork, track information, and previous/play-pause/next controls.
- All widgets use the existing shared PlayerController/ExoPlayer instance.
- Widget refreshes now follow playback state, track changes, stream metadata, and artwork updates.
- Dynamic Spot support uses Android's standard media-session integration; third-party app behavior still requires device testing.

## Validation
- All Android XML resources parsed successfully.
- Widget resource IDs and manifest registrations checked.
- A Gradle/APK build was not run in this environment because Java, Gradle, and the Android SDK are unavailable.
